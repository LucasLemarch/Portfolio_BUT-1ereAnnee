public class ControleurGUI
{
	private DrEureka metier;
	private FrameJeu ihm;

	public ControleurGUI()
	{
		this.metier = new DrEureka();
		this.ihm    = new FrameJeu( this );
	}

	public void action( int numAction, int tube1, int tube2 )
	{
		switch (numAction)
		{
			case 1 : metier.retourner(tube1-1)			; break ;
			case 2 : metier.echanger(tube1-1, tube2-1)	; break ;
			case 3 : metier.deplacer(tube1-1, tube2-1)	; break ;
			case 4 : metier.niveauSuivant()				; break ;
			case 5 : break ; //fermer la page
		}
		ihm.majIHM();
	}

	public String getTube  ( char type, int numTube ) { return metier.getTube( type, numTube ); }
	public int    getNiveau()                         { return metier.getNiveau()               ; }

	public String getImage(int lig, int col)
	{
		String tube;

		if ( col < 3 )
			tube = this.getTube('C', col);
		else
			tube = this.getTube('O', col-3);

		lig = 3 - lig; // on retourne la valeur de lig
		if (tube.length() > lig)
			switch ( tube.charAt(lig) )
			{
				case 'R' : return "./images/rouge.gif";
				case 'V' : return "./images/vert.gif";
				case 'M' : return "./images/mauve.gif";
			}

		return "./images/vide.gif";
	}

	public static void main( String[] a ) { new ControleurGUI() ; }
}
