import java.util.Scanner;
import java.io.FileReader;
import iut.algo.Decomposeur;

public class DrEureka
{
	private int niveau ;

	private Pile[] ensChimiste ;
	private Pile[] ensObjectif ;

	public DrEureka()
	{
		this.niveau = 1;
		this.ensChimiste = DrEureka.initChimiste();
		this.ensObjectif = DrEureka.initObjectif(this.niveau);
	}

	public String getTube( char type, int numTube )
	{
		if (type == 'C')
			return ensChimiste[numTube].toString() ;
		else
			return ensObjectif[numTube].toString() ;
	}

	public int getNiveau() { return this.niveau ; }

	public void niveauSuivant()
	{
		this.ensObjectif = DrEureka.initObjectif(++this.niveau);
	}

	public void retourner( int numTube )
	{
		this.ensChimiste[numTube].retourner() ;
	}

	public void echanger( int num1, int num2)
	{
		Pile tmp               = this.ensChimiste[num1];
		this.ensChimiste[num1] = this.ensChimiste[num2];
		this.ensChimiste[num2] = tmp;
	}

	public void deplacer( int numSource, int numDest )
	{
		if (!this.ensChimiste[numSource].estVide  () &&
			!this.ensChimiste[numDest  ].estPleine()    )
			this.ensChimiste[numDest].empiler(this.ensChimiste[numSource].depiler());
	}

	private static Pile[] initChimiste()
	{
		Pile[] tmp = new Pile[3];
		tmp[0] = new Pile(4);
		tmp[1] = new Pile(4);
		tmp[2] = new Pile(4);
		
		for (int cpt = 0 ; cpt < 2 ; cpt++)
		{
			tmp[0].empiler('R');
			tmp[1].empiler('V');
			tmp[2].empiler('M');
		}

		return tmp;
	}

	private static Pile[] initObjectif( int numObj )
	{
		FileReader	fr;
		Scanner		sc;
		Decomposeur	dec;

		char	val;
		String	lien;

		Pile[] tmp = new Pile[3];
		tmp[0] = new Pile(4);
		tmp[1] = new Pile(4);
		tmp[2] = new Pile(4);

		try
		{
			lien = "niveaux/niveau_" + String.format("%02d",numObj) + ".data";
			fr   = new FileReader(lien);
			sc   = new Scanner   (fr  );

			while (sc.hasNextLine())
			{
				dec = new Decomposeur(sc.nextLine());

				for (int cpt = 0 ; cpt < tmp.length ; cpt++)
				{
					val = dec.getChar(cpt);
					if (!(val == '.')) tmp[cpt].empiler(val);
				}
			}
		}
		catch (Exception e) {e.printStackTrace();}

		for (int cpt = 0 ; cpt < tmp.length ; cpt++)
			tmp[cpt].retourner();

		return tmp;
	}
}
