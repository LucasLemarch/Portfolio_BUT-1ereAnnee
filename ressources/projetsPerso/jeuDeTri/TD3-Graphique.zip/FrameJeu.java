import javax.swing.*;
import java.awt.BorderLayout;

public class FrameJeu extends JFrame
{
	private PanelTube  panelTube ;
	private PanelChoix panelChoix;

	public FrameJeu( ControleurGUI ctrl)
	{
		this.setSize    ( 1000, 480  );
		this.setLayout(new BorderLayout( 3, 3) );

		this.panelTube  = new PanelTube  ( ctrl );
		this.panelChoix = new PanelChoix ( ctrl );
		this.add ( this.panelTube , BorderLayout.CENTER );
		this.add ( this.panelChoix, BorderLayout.SOUTH  );

		this.setVisible ( true );
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public void majIHM()
	{
		this.panelTube.majIHM();
	}
}