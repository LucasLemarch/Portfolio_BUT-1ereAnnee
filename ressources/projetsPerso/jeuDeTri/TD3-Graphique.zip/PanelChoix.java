import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.*;


import java.awt.event.*;

public class PanelChoix extends JPanel implements ActionListener
{
	ControleurGUI ctrl;

	JButton   [] tabBtn;
	JLabel    [] tabLblTube;
	JTextField[] tabTxtTube;
	JButton      dernierBouton;

	String[][] tabChoix = new String[][] {{"btn", "btn", null, "lbl", "txt", null , null },
                                          {"btn", "btn", null, "lbl", "txt", "btn", "btn"}};

	
	public PanelChoix(ControleurGUI ctrl)
	{
		this.ctrl = ctrl;
		this.dernierBouton = null;

		this.setBackground(Color.GRAY);
		this.setLayout ( new GridLayout ( 2, 7 ) );

		int cas;
		int cptBtn = 0, cptLbl = 0, cptTxt = 0;
		String[] tabNom = new String[] {"Retourner 1 tube", "Echanger 2 tubes", "Deplacer 1 bille",
										"Niveau suivant"  , "Valider"         , "Quitter"         };

		this.tabBtn     = new JButton   [6];
		this.tabLblTube = new JLabel    [2];
		this.tabTxtTube = new JTextField[2];

		// Création et positionnement des Composants
		for (int lig=0; lig<tabChoix.length; lig++ )
			for (int col=0; col<tabChoix[lig].length; col++ )
			{
				     if ( tabChoix[lig][col] == "btn" )	cas=0;
				else if ( tabChoix[lig][col] == "lbl" )	cas=1;
				else if ( tabChoix[lig][col] == "txt" )	cas=2;
				else									cas=3;

				switch ( cas )
				{
					case 0 : this.tabBtn[cptBtn] = new JButton(tabNom[cptBtn]);
							 this.tabBtn[cptBtn].addActionListener( this );
							 this.add(this.tabBtn[cptBtn++]);
					         break;

					case 1 : this.tabLblTube[cptLbl] = new JLabel("");
							 this.add(this.tabLblTube[cptLbl++]);
					         break;

					case 2 : this.tabTxtTube[cptTxt] = new JTextField("", 1);
							 this.tabTxtTube[cptTxt].setBackground(Color.GRAY);
							 this.tabTxtTube[cptTxt].addActionListener( this );
							 this.add(this.tabTxtTube[cptTxt++]);
					         break;
					
					case 3 : this.add(new JLabel(new ImageIcon("images/vide.gif")));
					         break;
				}
			}
	}

	public void actionPerformed ( ActionEvent e)
	{
		int val1, val2;
		String txt1, txt2;

		for (int cpt = 0 ; cpt < this.tabBtn.length ; cpt++)
		{
			if (e.getSource() == this.tabBtn[cpt])
			{
				if (cpt == 0)
				{
					this.reinitialiser();
					this.tabLblTube[0].setText("numero du tube :");
					this.tabTxtTube[0].setBackground(Color.WHITE);
					this.dernierBouton = this.tabBtn[0];
				}
				if (cpt == 1 || cpt == 2)
				{
					this.tabLblTube[0].setText("tube origine :");
					this.tabLblTube[1].setText("tube destination :");
					this.tabTxtTube[0].setBackground(Color.WHITE);
					this.tabTxtTube[1].setBackground(Color.WHITE);
					this.dernierBouton = this.tabBtn[cpt];
				}
				if (cpt == 3)
				{
					this.reinitialiser();
					ctrl.action(4, 0, 0);
				}
				if (cpt == 4)
				{
					if (!(this.dernierBouton == null))
					{
						txt1 = this.tabTxtTube[0].getText();
						txt2 = this.tabTxtTube[1].getText();
						if ( this.dernierBouton == this.tabBtn[0] && !(txt1 == ""))
						{
							val1 = Integer.parseInt(this.tabTxtTube[0].getText());
							if ( val1 >= 1 && val1 <=3 )
								ctrl.action(1, val1, 0);
						}
						if ( this.dernierBouton == this.tabBtn[1] && !(txt1 == "") && !(txt2 == ""))
						{
							val1 = Integer.parseInt(this.tabTxtTube[0].getText());
							val2 = Integer.parseInt(this.tabTxtTube[1].getText());
							if ( val1 >= 1 && val1 <=3 && val2 >= 1 && val2 <=3 )
								ctrl.action(2, val1, val2);
						}
						if ( this.dernierBouton == this.tabBtn[2] && !(txt1 == "") && !(txt2 == ""))
						{
							val1 = Integer.parseInt(this.tabTxtTube[0].getText());
							val2 = Integer.parseInt(this.tabTxtTube[1].getText());
							if ( val1 >= 1 && val1 <=3 && val2 >= 1 && val2 <=3 )
								ctrl.action(3, val1, val2);
						}
						this.reinitialiser();
					}
				}
				if (cpt == 5)
				{
					ctrl.action(5, 0, 0);
				}
			}
		}
		
	}
	private void reinitialiser()
	{
		this.tabLblTube[0].setText("");
		this.tabLblTube[1].setText("");
		this.tabTxtTube[0].setBackground(Color.GRAY);
		this.tabTxtTube[0].setText("");
		this.tabTxtTube[1].setBackground(Color.GRAY);
		this.tabTxtTube[1].setText("");
		this.dernierBouton = null;
	}
}
