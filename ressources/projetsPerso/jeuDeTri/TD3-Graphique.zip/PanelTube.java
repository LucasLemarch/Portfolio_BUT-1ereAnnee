

import java.awt.GridLayout;

import javax.swing.*;



public class PanelTube extends JPanel
{
	ControleurGUI ctrl;

	JLabel     lblNiveau;
	JLabel[][] tabLblBille;

	String[][] tabTube = new String[][] {{"niveau", null   , null, null          , null, null   , null, null, null   , null, null          , null, null   , null},
										 {null    , null   , null, "lbl_chimiste", null, null   , null, null, null   , null, "lbl_objectif", null, null   , null},
										 {"BG"    , "boulC", "BM", "boulC"       , "BM", "boulC", "BD", "BG", "boulO", "BM", "boulO"       , "BM", "boulO", "BD"},
										 {"BG"    , "boulC", "BM", "boulC"       , "BM", "boulC", "BD", "BG", "boulO", "BM", "boulO"       , "BM", "boulO", "BD"},
										 {"BG"    , "boulC", "BM", "boulC"       , "BM", "boulC", "BD", "BG", "boulO", "BM", "boulO"       , "BM", "boulO", "BD"},
										 {"BG"    , "boulC", "BM", "boulC"       , "BM", "boulC", "BD", "BG", "boulO", "BM", "boulO"       , "BM", "boulO", "BD"},
										 {null    , "lbl_1", null, "lbl_2"       , null, "lbl_3", null, null, null   , null, null          , null, null   , null}};

	public PanelTube(ControleurGUI ctrl)
	{
		this.ctrl = ctrl;

		this.setLayout ( new GridLayout ( 7, 14 ) );

		int cas;
		String[] val;
		String   lien;
		int x,y;
		this.tabLblBille = new JLabel [4][6];

		// Création et positionnement des Composants
		for (int lig=0; lig<tabTube.length; lig++ )
			for (int col=0; col<tabTube[lig].length; col++ )
			{
				     if ( tabTube[lig][col] == null )				cas=0;
				else if ( tabTube[lig][col].startsWith ("lbl_" ) )	cas=1;
				else if ( tabTube[lig][col].startsWith ("boul" ) )	cas=2;
				else if ( tabTube[lig][col] == "niveau" )			cas=3;
				else												cas=4;

				switch ( cas )
				{
					case 0 : this.add(new JLabel(new ImageIcon("images/vide.gif")));
					         break;

					case 1 : val = tabTube[lig][col].split("_");
							 this.add(new JLabel( val[1], SwingConstants.CENTER ));
					         break;

					case 2 : if (tabTube[lig][col].charAt(4) == 'C')
							 {
								x = lig-2;
								y = (col-1)/2;
							 }
							 else
							 {
								x = lig-2;
								y = (col-2)/2;
							 }
							 this.tabLblBille[x][y] = new JLabel(new ImageIcon(ctrl.getImage(x,y)));
							 this.add(this.tabLblBille[x][y]);
					         break;
					
					case 3 : this.lblNiveau = new JLabel("Niveau : " + ctrl.getNiveau());
							 this.add(this.lblNiveau);
					         break;

					case 4 : lien = "images/" + tabTube[lig][col] + ".gif";
							 this.add(new JLabel(new ImageIcon( lien )));
							 break;
				}
			}
	}

	public void majIHM()
	{
		for ( int lig=0; lig<4; lig++)
			for ( int col=0; col<6; col++)
				this.tabLblBille[lig][col].setIcon(new ImageIcon(ctrl.getImage(lig, col)));
		
		this.lblNiveau.setText("Niveau : " + ctrl.getNiveau());
	}
}
