public class Pile
{
	private char[] ensCarac;
	private int    sommet;

	public Pile( int nbEltTot )
	{
		this.ensCarac = new char[nbEltTot];
		this.sommet   = 0;
	} 

	public Pile( Pile p )
	{
		this.ensCarac = new char[p.ensCarac.length];
		this.sommet   = p.sommet;

		for ( int cpt = 0 ; cpt < this.sommet ; cpt++ )
			this.ensCarac[cpt] = p.ensCarac[cpt];
	}

	public boolean estVide()
	{
		return this.sommet == 0;
	}
	
	public boolean estPleine()
	{
		return this.sommet == this.ensCarac.length;
	}

	public boolean empiler( char c )
	{
		if ( this.estPleine() ) return false;

		this.ensCarac[this.sommet++] = c;
		return true;
	}

	public char depiler()
	{
		if ( this.estVide() ) return ' ';

		return this.ensCarac[--this.sommet];
	}

	public void retourner()
	{
		char[] temp = new char[this.ensCarac.length];

		for (int cpt = 0 ; cpt < this.sommet; cpt++)
			temp[cpt] = this.ensCarac[this.sommet - cpt - 1];

		this.ensCarac = temp;
	}

	public String toString()
	{
		String sRet = "";

		for (int cpt = 0 ; cpt < this.sommet ; cpt++)
			sRet +=  this.ensCarac[cpt];

		return sRet;

		//return Arrays.toString(this.ensCarac);
	}

	public static void main(String[] arg)
	{
		Pile p1 = new Pile(4);
		p1.empiler('A');
		p1.empiler('B');
		p1.empiler('C');
		p1.empiler('D');

		Pile p2 = new Pile(p1);
		p2.retourner();

		System.out.println(p1);
		System.out.println(p2.depiler());
		System.out.println(p2);

	}
}