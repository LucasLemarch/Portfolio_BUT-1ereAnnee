--Script de création du cas PERSO

--Suppression d'éventuelles tables 
DROP TABLE Episode;
DROP TABLE Saison;
DROP TABLE StudioAnimation;
DROP TABLE Producteur;
DROP TABLE Anime;
DROP TABLE OeuvreOriginale;

--Création de la table OeuvreOrignale
CREATE TABLE OeuvreOriginale(
    numOeuvre   serial  PRIMARY KEY,
    nomOeuvre   text    NOT NULL,
    typeOeuvre  varchar(5) CHECK (typeOeuvre IN ('Manga','Jeu'))
);

--Création de la table Anime
CREATE TABLE Anime(
    numAnime        serial  PRIMARY KEY,
    nomAnime        text    NOT NULL,
    dtePubliInit    date    NOT NULL,
    dtePubliFin     date,
    numOeuvre       int     REFERENCES OeuvreOriginale(numOeuvre)
);

--Création de la table Producteur
CREATE TABLE Producteur(
    numProducteur       serial  PRIMARY KEY,
    nomProducteur       text    NOT NULL,
    prenomProducteur    text,
    dteNaissProducteur  date,
    dteDecesProducteur  date,
    nationalite         text
);
--Création de la table StudioAnimation
CREATE TABLE StudioAnimation(
    numStudio           serial  PRIMARY KEY,
    nomStudio           text    NOT NULL,
    effectif            int,
    dteCreationStudio   date, 
    dteFermetureStudio  date,
    lieuSiege           text
);

--Création de la table Saison
CREATE TABLE Saison(
    numAnime            int     REFERENCES Anime(numAnime),
    numSaison           int     NOT NULL,
    nomSaison           text,
    nbEpisodes          int     NOT NULL,
    numProducteur       int     REFERENCES Producteur(numProducteur),
    numStudioAnimation  int     REFERENCES StudioAnimation(numStudio),
    PRIMARY KEY (numAnime, numSaison)
);

CREATE TABLE Episode(
    numAnime    int,
    numSaison   int,
    numEpisode  int     NOT NULL,
    nomEpisode  text,
    duree       time    NOT NULL,
    FOREIGN KEY (numAnime,numSaison) REFERENCES Saison(numAnime, numSaison),
    PRIMARY KEY (numAnime,numSaison,numEpisode)
);

