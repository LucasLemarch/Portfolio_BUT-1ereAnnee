--Lister tous les studios d’animation.

SELECT  *
FROM    StudioAnimation;

/*Résultat :
 numstudio |      nomstudio      | effectif | dtecreationstudio | dtefermeturestudio | lieusiege 
-----------+---------------------+----------+-------------------+--------------------+-----------
         1 | David Production    |       93 | 2007-09-01        |                    | Japon
         2 | Wit Studio          |      109 | 2012-06-01        |                    | Japon
         3 | Studio Pierrot      |      158 | 1979-05-01        |                    | Japon
         4 | MAPPA               |      250 | 2011-06-14        |                    | Japon
         5 | OLM                 |      216 | 1994-06-01        |                    | Japon
         6 | ufotable            |      200 | 2000-10-01        |                    | Japon
         7 | Fortiche Production |      226 | 2009-09-06        |                    | France
(7 lignes)
*/