--Afficher tous les épisodes de la saison 3 de L’attaque des titans.

SELECT  e.*
FROM    Episode e JOIN Anime a ON  e.numAnime = a.numAnime
WHERE   nomAnime ='L''Attaque des Titans' AND
        numSaison = 3;