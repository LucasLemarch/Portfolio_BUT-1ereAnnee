--Afficher les saisons produites par Wada George et animé par Wit Studio.

SELECT *
FROM   Saison
WHERE  numProducteur = (    SELECT numProducteur
                            FROM   Producteur
                            WHERE  prenomProducteur = 'George' AND
                                nomProducteur = 'Wada')       AND
       numStudioAnimation = ( SELECT numStudio
                     FROM   StudioAnimation
                     WHERE  nomStudio = 'Wit Studio');

