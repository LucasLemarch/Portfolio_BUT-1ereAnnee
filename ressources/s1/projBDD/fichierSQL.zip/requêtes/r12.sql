--Afficher tous les épisodes venant de l'œuvre originale Naruto.

SELECT  e.*
FROM    Episode e JOIN Anime a ON e.numAnime = a.numAnime
WHERE   numOeuvre = (SELECT numOeuvre
                     FROM   OeuvreOriginale
                     WHERE  nomOeuvre = 'Naruto');

/* Résultat :
numanime | numsaison | numepisode |                    nomepisode                     |  duree   
----------+-----------+------------+---------------------------------------------------+----------
        2 |         1 |          1 | Et voici Naruto Uzumaki                           | 00:22:00
        2 |         1 |          2 | Je m'appelle Konohamaru                           | 00:22:00
        2 |         1 |          3 | Sasuke et Sakura : Amis ou Ennemis ?              | 00:22:00
        2 |         2 |          1 | Le Journal de l'école de Konoha                   | 00:22:00
        2 |         2 |          2 | La Seconde Épreuve ! Tout le monde est un ennemi  | 00:22:00
        2 |         2 |          3 | Manger ou être mangé... Naruto joue les appâts !  | 00:22:00
        2 |         3 |          1 | Le Retour d'Ebisu                                 | 00:22:00
        2 |         3 |          2 | L'ermite est de retour                            | 00:22:00
        2 |         3 |          3 | La Technique d'invocation                         | 00:22:00
        2 |         4 |          1 | Naruto sort le grand jeu                          | 00:22:00
        2 |         4 |          2 | Le Coup final                                     | 00:22:00
        2 |         4 |          3 | Konoha pleure le 3e Hokage                        | 00:22:00
        2 |         5 |          1 | Orages sur Nagi                                   | 00:22:00
        2 |         5 |          2 | Juste avant l'arrivée ! La bataille fait rage…    | 00:22:00
        2 |         5 |          3 | La Dernière Ligne droite pour Idate               | 00:22:00
(33 lignes)
*/