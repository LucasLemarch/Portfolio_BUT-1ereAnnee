--Afficher les animés animé par Ufotable et Fortiche Production.

--A : les animés animé par Ufotable
--B : les animés animé par Fortiche Production
--              A UNION B

SELECT  a.*
FROM    anime a JOIN saison s ON a.numAnime = s.numAnime
WHERE   numStudioAnimation = (  SELECT  numStudio
                                FROM    StudioAnimation
                                WHERE   nomStudio = 'Ufotable')

UNION

SELECT  a.*
FROM    anime a JOIN saison s ON a.numAnime = s.numAnime
WHERE   numStudioAnimation = (  SELECT  numStudio
                                FROM    StudioAnimation
                                WHERE   nomStudio = 'Fortiche Production');