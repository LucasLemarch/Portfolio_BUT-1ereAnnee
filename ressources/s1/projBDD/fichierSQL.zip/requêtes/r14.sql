--Ajouter 1 épisode à toutes les saisons de Jojo’s Bizarre Adventure.

UPDATE  saison
SET     nbEpisodes = nbEpisodes + 1
WHERE   numAnime = (SELECT  numAnime
                    FROM    anime
                    WHERE   nomAnime = 'Jojo''s Bizarre Adventure');