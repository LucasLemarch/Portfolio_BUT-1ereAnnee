--Renommer l’attribut duree de la table Episode en tempsEpisode.

ALTER TABLE Episode
RENAME COLUMN duree TO tempsEpisode;
