--Lister les œuvres originales qui viennent d’un manga.

SELECT  *
FROM    OeuvreOriginale
WHERE   typeOeuvre = 'Manga';

/* Résultat :
 numoeuvre |        nomoeuvre         | typeoeuvre 
-----------+--------------------------+------------
         1 | Jojo's Bizarre Adventure | Manga
         2 | Naruto                   | Manga
         3 | L'Attaque des Titans     | Manga
         4 | Demon slayer             | Manga
         5 | Vinland Saga             | Manga
(5 lignes)
*/