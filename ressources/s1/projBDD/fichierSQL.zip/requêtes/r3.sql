--Afficher le nom et la durée des épisodes durant plus de 40 minutes.

SELECT  nomEpisode, duree
FROM    Episode
WHERE   duree > '00:40:00';

/* Résultat :
                     nomepisode                     |  duree   
----------------------------------------------------+----------
 Kimetsu no Yaiba - Le film : Le train de l'Infini  | 02:00:26
 Uzui Tengen, le pilier du son                      | 00:46:59
 Welcome to the Playground                          | 00:45:00
 Certains mystères ne devraient jamais être résolus | 00:45:00
 Cette violence crasse nécessaire au changement     | 00:45:00
 Joyeuse Fête du progrès !                          | 00:45:00
 L'ennemi commun                                    | 00:45:00
 Quand l'empire s'effondre                          | 00:45:00
 Le petit sauveur                                   | 00:45:00
 L'eau et l'huile                                   | 00:45:00
 Rouages et engrenages                              | 00:45:00
(11 lignes)
*/