--Afficher les numéros des animes, les numéros et les noms des saisons qui contiennent entre 25 et 40 épisodes.

SELECT  numAnime, numSaison, nomSaison
FROM    Saison
WHERE   nbEpisodes BETWEEN 25 AND 40;

/*Résultat :
 numanime |            nomsaison            | numsaison 
----------+---------------------------------+-----------
        1 | Phantom Blood / Battle Tendency |         1
        1 | Diamond is Unbreakable          |         3
        1 | Golden Wind                     |         4
        2 |                                 |         1
        2 |                                 |         2
        2 |                                 |         3
        2 |                                 |         4
        2 |                                 |         5
        2 |                                 |         6
        2 |                                 |         7
        3 |                                 |         1
        4 |                                 |         1
        5 |                                 |         1
        7 | Iles Oranges                    |         2
(14 lignes)
*/