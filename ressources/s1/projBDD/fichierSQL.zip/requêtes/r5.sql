--Afficher la liste des épisodes commençant par “Le monde de Dio”.
SELECT  *
FROM    Episode
WHERE   nomEpisode LIKE 'Le monde de Dio%';

/* Résultat :
 numanime | numsaison | numepisode |         nomepisode         |  duree   
----------+-----------+------------+----------------------------+----------
        1 |         2 |         45 | Le monde de Dio – Partie 1 | 00:25:00
        1 |         2 |         46 | Le monde de Dio – Partie 2 | 00:26:00
        1 |         2 |         47 | Le monde de Dio – Partie 3 | 00:22:00
(3 lignes)
*/