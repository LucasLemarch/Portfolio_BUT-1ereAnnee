--Donner le nombre de saisons que possède l’animé L’attaque des titans.

SELECT  COUNT(*)
FROM    Saison s JOIN Anime a
        ON s.numAnime = a.numAnime
WHERE   nomAnime = 'L''Attaque des Titans';

/* Résultat :
 count 
-------
     4
(1 ligne)
*/