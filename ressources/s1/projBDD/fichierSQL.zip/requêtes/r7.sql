--Afficher le nom des producteurs dans l’ordre décroissant.

SELECT      nomProducteur
FROM        Producteur
ORDER BY    nomProducteur DESC;

/* Résultat :
 nomproducteur 
---------------
 Yuyama
 Yasuhiro
 Yabuta
 Wada
 Naokatsu
 Linke
 Kondo
 Hayashi
 Gujima
(9 lignes)
*/