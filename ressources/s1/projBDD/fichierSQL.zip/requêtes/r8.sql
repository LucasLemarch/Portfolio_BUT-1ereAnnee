--Afficher tous les animés venant de l'œuvre originale Naruto.

SELECT  nomAnime
FROM    Anime a JOIN OeuvreOriginale o
        ON a.numOeuvre = o.numOeuvre
WHERE   nomOeuvre = 'Naruto';

/*Résultat :
     nomanime     
------------------
 Naruto
 Naruto Shippuden
(2 lignes)
*/