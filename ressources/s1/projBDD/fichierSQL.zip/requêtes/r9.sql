--Lister toutes les saisons d’animé ne venant pas d’un animé qui sont toujours en cours.

--A : toutes les saisons d’animé
--B : toutes les saisons d’animé qui sont terminé
--             A EXCEPT B

SELECT  *
FROM    saison

EXCEPT

SELECT  s.*
FROM    saison s JOIN anime a ON s.numAnime = a.numAnime
WHERE   NOT dtePubliFin = null;