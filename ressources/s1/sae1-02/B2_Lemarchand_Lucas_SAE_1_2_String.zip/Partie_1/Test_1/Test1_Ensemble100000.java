import iut.algo.*;
//@author LEMARCHAND Lucas B2

public class Test1_Ensemble100000
{
	public static void main(String[] a)
	{
		/*-----------------*/
		/*  Données        */
		/*-----------------*/

		/*----Constante----*/
		final int TAILLE = 100000;

		/*----Variable-----*/
		char[]	tabLet;
		String	chaineLet;
		long	tpsDebut, tpsFin, tpsDiff;

		/*-----------------*/
		/*  Instructions   */
		/*-----------------*/
		tabLet = new char[TAILLE];
		tpsDebut = System.currentTimeMillis();
		
		for (int i = 0 ; i < TAILLE ; i++)
		{
			tabLet[i] = (char)('A' + (int)(Math.random() * 26));
		}
		
		tpsFin = System.currentTimeMillis();
		tpsDiff = tpsFin - tpsDebut;
		System.out.println("Temps pour remplir le tableau : " + tpsDiff);


		chaineLet = "";
		tpsDebut = System.currentTimeMillis();
		
		for (int i = 0 ; i < TAILLE ; i++)
		{
			chaineLet = chaineLet + (char)('A' + (int)(Math.random() * 26));
		}
		
		tpsFin = System.currentTimeMillis();
		tpsDiff = tpsFin - tpsDebut;
		System.out.println("Temps pour remplir la chaine avec concatenation : " + tpsDiff);


		tpsDebut = System.currentTimeMillis();
		
		chaineLet = new String(tabLet);
		
		tpsFin = System.currentTimeMillis();
		tpsDiff = tpsFin - tpsDebut;
		System.out.println("Temps pour remplir la chaine avec un tableau : " + tpsDiff);
	}
}
