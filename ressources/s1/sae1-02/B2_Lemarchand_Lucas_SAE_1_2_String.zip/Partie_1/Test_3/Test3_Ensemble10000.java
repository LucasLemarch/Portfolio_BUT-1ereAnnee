import iut.algo.*;
//@author LEMARCHAND Lucas B2

public class Test3_Ensemble10000
{
	public static void main(String[] a)
	{
		/*-----------------*/
		/*  Données        */
		/*-----------------*/

		/*----Constante----*/
		final int TAILLE = 10000;

		/*----Variable-----*/
		char[]	tabLet, sansMajTabLet;
		String	chaineLet, sansMajChaineLet;
		long	tpsDebut, tpsFin, tpsDiff;
		
		/*-----------------*/
		/*  Instructions   */
		/*-----------------*/
		tabLet = new char[TAILLE];
		for (int i = 0 ; i < TAILLE ; i++)
		{
			tabLet[i] = (char)('A' + (int)(Math.random() * 26));
		}
		chaineLet = new String(tabLet);


		sansMajTabLet = new char[TAILLE];
		tpsDebut = System.currentTimeMillis();
		
		for (int i = 0 ; i < TAILLE ; i++)
		{
			if (estVoyelle(tabLet[i]))
			{
				sansMajTabLet[i] = (char)(tabLet[i] + 32);
			}
			else
			{
				sansMajTabLet[i] = tabLet[i];
			}
		}
		
		tpsFin = System.currentTimeMillis();
		tpsDiff = tpsFin - tpsDebut;
		System.out.println("Temps pour traiter le tableau : " + tpsDiff);


		sansMajChaineLet = "";
		tpsDebut = System.currentTimeMillis();
		
		for (int i = 0 ; i < TAILLE ; i++)
		{
			if (estVoyelle(chaineLet.charAt(i)))
			{
				sansMajChaineLet = sansMajChaineLet + ((char)(chaineLet.charAt(i) + 32));
			}
			else
			{
				sansMajChaineLet = sansMajChaineLet + chaineLet.charAt(i);
			}
		}
		
		tpsFin = System.currentTimeMillis();
		tpsDiff = tpsFin - tpsDebut;
		System.out.println("Temps pour traiter la chaine : " + tpsDiff);
	}
	private static boolean estVoyelle (char let)
	{
		if (let == 'A' || let == 'E' || let == 'I' || let == 'O' || let == 'U' || let == 'Y')
		{
			return true;
		}
		return false;
	}
}
