import iut.algo.*;
//@author LEMARCHAND Lucas B2

public class Test2_Ensemble10000
{
	public static void main(String[] a)
	{
		/*-----------------*/
		/*  Données        */
		/*-----------------*/

		/*----Constante----*/
		final int TAILLE = 10000;

		/*----Variable-----*/
		char[]			tabLet;
		StringBuilder	chaineLet;
		long			tpsDebut, tpsFin, tpsDiff;
		int[]			tabOccu;
		
		/*-----------------*/
		/*  Instructions   */
		/*-----------------*/
		tabLet = new char[TAILLE];
		for (int i = 0 ; i < TAILLE ; i++)
		{
			tabLet[i] = (char)('A' + (int)(Math.random() * 26));
		}
		chaineLet = new StringBuilder();
		chaineLet.append(tabLet);
		
		
		tabOccu = new int[26];
		tpsDebut = System.currentTimeMillis();
		
		for (int i = 0 ; i < TAILLE ; i++)
		{
			tabOccu[(int)(tabLet[i] - 'A')]++;
		}
		
		tpsFin = System.currentTimeMillis();
		tpsDiff = tpsFin - tpsDebut;
		System.out.println("Temps pour parcourir le tableau : " + tpsDiff);


		tabOccu = new int[26];
		tpsDebut = System.currentTimeMillis();
		
		for (int i = 0 ; i < TAILLE ; i++)
		{
			tabOccu[(int)(chaineLet.charAt(i) - 'A')]++;
		}
		
		tpsFin = System.currentTimeMillis();
		tpsDiff = tpsFin - tpsDebut;
		System.out.println("Temps pour parcourir la chaine : " + tpsDiff);
	}
}
