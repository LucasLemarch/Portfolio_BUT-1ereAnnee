import iut.algo.*;
public class Exercice1_SAE
{
    //@author Groupe_27
    public static void main(String[] a)
    {
        /*---------------*/
        /*   Données     */
        /*---------------*/

        /*---Variable----*/ 
        short		cpt;
        short[]		tab;
        short		saisie;

        /*---------------*/
        /* Instructions  */
        /*---------------*/
			
		Console.println("A quel mode de jeu souhaitez-vous jouer ? (normal : 1 / avance : 2)");
		saisie = Clavier.lire_short();
		while ((saisie != 1 ) && (saisie != 2))
		{
			Console.println("Valeur incorrect");
			Console.println("A quel mode de jeu souhaitez-vous jouer ? (normal : 1 / avance : 2)");
			saisie = Clavier.lire_short();
		}

		if (saisie == 1)
		{
			tab = new short[] {0,1,3,5,7,9,11,15,20,25,30,35,40,50,60,70,85,100,150,300};
		}
		else
		{
			tab = new short[] {0,1,3,5,7,3,11,15,20,25,30,20,40,50,60,70,50,100,150,300};
		}
	}
}