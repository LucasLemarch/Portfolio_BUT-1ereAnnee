import iut.algo.*;
public class Exercice2_SAE
{
    //@author Groupe_27
    public static void main(String[] a)
    {
        /*---------------*/
        /*   Données     */
        /*---------------*/

        /*---Constante---*/
        final short TAILLE = 40;

        /*---Variable----*/ 
        short	cpt;
		short[]	nbVal;
        short[]	sac;
        
        /*---------------*/
        /* Instructions  */
        /*---------------*/
        
        sac = new short[TAILLE];
		nbVal = new short[] {0};
        
        cpt = 1;
		nbVal[0]++;
    	sac[0] = -1;
        while (cpt <= 30)
        {
          if ((cpt >= 11) && (cpt <= 19))
          {
            sac[nbVal[0]] = cpt;
            nbVal[0]++;
            sac[nbVal[0]] = cpt;
            nbVal[0]++;
          }
          else
          {
               sac[nbVal[0]] = cpt;
            nbVal[0]++;
          }
          cpt++;
        }
		
      	//Test
        cpt = 0;
        while (cpt < nbVal[0])
        {
            Console.print (sac[cpt] + " ");
            cpt++;
        }
		Console.println("\n" + Exercice2_SAE.Piocher(sac,nbVal));
		cpt = 0;
        while (cpt < nbVal[0])
        {
            Console.print (sac[cpt] + " ");
            cpt++;
        }
    }
	private static short Piocher(short[] sac, short[] nbVal)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/
		short	indice, val, retenu;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		indice			= (short)(Math.random() * nbVal[0]);
		retenu			= sac[nbVal[0]-1];
		val				= sac[indice];
		sac[nbVal[0]-1]	= val;
		sac[indice]		= retenu;

		nbVal[0]--;
		return val;
	}
}