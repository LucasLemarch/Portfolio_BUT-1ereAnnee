import iut.algo.*;
public class Exercice3_SAE
{
	//@author Groupe_27
	public static void main(String[] a)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Constante---*/
		final short LONG = 20;

		/*---Variable----*/ 
		short cpt, tour, val, choix;
		short[] serpent;
		boolean choixCase;
		
		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		serpent = new short[LONG];
		
		// remplir le tableau de 0
		cpt = 0;
		while (cpt < LONG)
		{
			serpent[cpt] = 0;
			cpt++;
		}
      
		cpt = 0;											//debut affichage tableau
		while (cpt < LONG)
		{
			Console.print("+-" + String.format("%02d", cpt+1) + "-");
			cpt++;
		}
		Console.print("+\n");
      
		cpt = 0;
		while (cpt < LONG)
		{
			Console.print("| " + String.format("%2d", serpent[cpt]) + " ");
			cpt++;
		}
		Console.print("|\n");
		
		cpt = 0;
		while (cpt < LONG)
		{
			Console.print("+----");
			cpt++;
		}
		Console.print("+\n");							//fin affichage tableau
		
		tour = 0;
		while (tour < LONG)
		{
			Console.print("Choisissez une nombre : ");	//choix nombre	
			val = Clavier.lire_short();
			
			choixCase = true;								//choix case
			while (choixCase)
			{
				Console.print("Choisissez dans quelle case vous souhaitez la placer : ");
				choix = Clavier.lire_short();
				if (choix >= 1 && choix <= LONG)
				{
					if (serpent[choix-1] == 0)
					{
						serpent[choix-1] = val;
						choixCase = false;	
					}
					else
					{	
						Console.println("Cette case est déja prise veuillez en choisir une autre");
					}
				}
				else
				{
					Console.println("Cette case n'existe pas veuillez en choisir une autre");
				}
			}												//fin choix case
          
			cpt = 0;										//debut affichage tableau
			while (cpt < LONG)
			{
				Console.print("+-" + String.format("%02d", cpt+1) + "-");
				cpt++;
			}
			Console.print("+\n");
			cpt = 0;
			while (cpt < LONG)
			{
				Console.print("| " + String.format("%2d", serpent[cpt]) + " ");
				cpt++;
			}
			Console.print("|\n");
			
			cpt = 0;
			while (cpt < LONG)
			{
				Console.print("+----");
				cpt++;
			}
			Console.print("+\n");						//fin affichage tableau
			
			tour++;
		}
	}
}