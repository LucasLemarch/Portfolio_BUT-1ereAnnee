import iut.algo.*;
public class Exercice4_SAE
{
	//@author Groupe_27
	public static void main(String[] a)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Constante---*/
		final short LONG = 20;

		/*---Variable----*/ 
		short cpt, derniereVal, longSuite, scoreFinal;
		short[] serpent;
		short[] tab;
		short saisie;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		serpent = new short[LONG];

		Console.println("A quel mode de jeu souhaitez-vous jouer ? (normal : 1 / avance : 2)");
		saisie = Clavier.lire_short();
		while ((saisie != 1 ) && (saisie != 2))
		{
			Console.println("Valeur incorrect");
			Console.println("A quel mode de jeu souhaitez-vous jouer ? (normal : 1 / avance : 2)");
			saisie = Clavier.lire_short();
		}

		if (saisie == 1)
		{
			tab = new short[] {0,1,3,5,7,9,11,15,20,25,30,35,40,50,60,70,85,100,150,300};
		}
		else
		{
			tab = new short[] {0,1,3,5,7,3,11,15,20,25,30,20,40,50,60,70,50,100,150,300};
		}

		cpt = 0;
		while (cpt < LONG)
		{
			serpent[cpt] = (short) (Math.random() *21);
			cpt++;
		}

		cpt = 0;
		while (cpt < LONG)
		{
			Console.print("+-" + String.format("%02d", cpt+1) + "-");
			cpt++;
		}
		Console.print("+\n");
		cpt = 0;
		while (cpt < LONG)
		{
			Console.print("| " + String.format("%2d", serpent[cpt]) + " ");
			cpt++;
		}
		Console.print("|\n");

		cpt = 0;
		while (cpt < LONG)
		{
			Console.print("+----");
			cpt++;
		}
		Console.print("+\n");

		cpt = longSuite = 1;
		derniereVal = tab[0];
		Console.print("	" + derniereVal + " ");
		scoreFinal = 0;
		while (cpt < LONG)
		{
			if( serpent[cpt] > derniereVal)
			{
				longSuite++;
				derniereVal = serpent[cpt];
				Console.print(derniereVal + " ");
			}
			else
			{
				Console.print( ": " + tab[longSuite-1] + "points\n");

				scoreFinal += tab[longSuite-1];
				longSuite = 1;
				derniereVal = serpent[cpt];

				Console.print("	" + derniereVal + " ");
			}
			cpt++;
		}
		Console.print(": " + tab[longSuite-1] + " points\n");

		scoreFinal += tab[longSuite-1];

		Console.println("Votre Score final est de : " + scoreFinal);
	}
}