import iut.algo.*;
public class Exercice5_SAE
{
	//@author Groupe_27
	public static void main(String[] a)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Constante---*/
		final short LONG = 20;


		/*---Variable----*/
		String	serpent;
		short[]	tab;
		short	cpt;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		tab = new short[LONG];
		
		// remplir le tableau de valeur aleatoire
		cpt = 0;
		while (cpt < LONG)
		{
			tab[cpt] = (short) (Math.random() *31);
			cpt++;
		}
		
		serpent  = "      -----\n";
		serpent += "    / O     \\--+-01-+-02-+-03-+    +-09-+-10-+-11-+    +-17-+-18-+-19-+\n";
		serpent += "====           | " + String.format("%2d", tab[0]) + " | " + String.format("%2d", tab[1]) + " | " + String.format("%2d", tab[2]) + " |    | " + String.format("%2d", tab[8]) + " | " + String.format("%2d", tab[9]) + " | " + String.format("%2d", tab[10]) + " |    | " + String.format("%2d", tab[16]) + " | " + String.format("%2d", tab[17]) + " | " + String.format("%2d", tab[18]) + " |\n";
		serpent += "    \\ O     /--+----+----+-04-+    +-08-+----+-12-+    +-16-+----+-20-+\n";
		serpent += "      -----              | " + String.format("%2d", tab[3]) + " |    | " + String.format("%2d", tab[7]) + " |    | " + String.format("%2d", tab[11]) + " |    | " + String.format("%2d", tab[15]) + " |    | " + String.format("%2d", tab[19]) + " |\n";
		serpent += "                         +-05-+-06-+-07-+    +-13-+-14-+-15-+    +----+\n";
		serpent += "                         | " + String.format("%2d", tab[4]) + " | " + String.format("%2d", tab[5]) + " | " + String.format("%2d", tab[6]) + " |    | " + String.format("%2d", tab[12]) + " | " + String.format("%2d", tab[13]) + " | " + String.format("%2d", tab[14]) + " |     \\  /\n";
		serpent += "                         +----+----+----+    +----+----+----+      \\/\n";
		
		Console.couleurFont ( CouleurConsole.VERT ); 
		Console.println(serpent);
		Console.normal();
	}
}