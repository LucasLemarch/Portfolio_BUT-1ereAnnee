import iut.algo.*;
public class Exercice7_SAE
{
	//@author Groupe_27
	public static void main(String[] args)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Constante---*/
		final short LONG = 20;

		/*---Variable----*/ 
		short	tour;
		short[]	score;
		short[]	serpentJ1, serpentJ2;
		short	pioche;
		short[]	nbVal;
		short[]	sac;
		short	scoreJ1, scoreJ2;	

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		score = Exercice7_SAE.ConfigurerScore();												//configurer les scores
		Console.println(Exercice7_SAE.AfficherScore(score));									//affichage score
		
		serpentJ1 = Exercice7_SAE.RemplirSerpentVide(LONG);										//remplir les serpents de 0
		serpentJ2 = Exercice7_SAE.RemplirSerpentVide(LONG);
		
		nbVal = new short[] {0};																	//variable contenant le nb de jeton actuel dans la pioche
		if (args.length == 0)																		//detection du mode de pioche
		{
			sac = Exercice7_SAE.RemplirPiocheNormal(nbVal);										
		}
		else
		{
			sac = Exercice7_SAE.RemplirPiocheEntree(nbVal,args[0]);
		}
		
		tour = 0;																				//PHASE DE JEU
		while (tour < LONG)																		//boucle pour remplir les serpents
		{
			
			pioche = Exercice7_SAE.Piocher(sac,nbVal);													//pioche
			Console.println("-------------------- TOUR " + String.format("%2d", (tour + 1)) + " : Le jeton pioche est : " + String.format("%2d", pioche) + " --------------------");
			
			Console.println("\nTOUR DU JOUEUR 1");														//tour du J1 + affichage
			Console.couleurFont ( CouleurConsole.VERT ); 
			Console.println(Exercice7_SAE.AfficherSerpent(serpentJ1));
			Console.normal();
			Exercice7_SAE.Tour(serpentJ1, LONG, pioche, nbVal);
			
			Console.println("\nTOUR DU JOUEUR 2");														//tour du J2 + affichage
			Console.couleurFont ( CouleurConsole.ROUGE );
			Console.println(Exercice7_SAE.AfficherSerpent(serpentJ2));
			Console.normal();
			Exercice7_SAE.Tour(serpentJ2, LONG, pioche, nbVal);
			
			tour++;
		}
		Console.println("------------------------------------ FIN -----------------------------------");
		Console.println("\nTOUR DU JOUEUR 1");
		Console.couleurFont ( CouleurConsole.VERT );
		Exercice7_SAE.Jocker(serpentJ1, LONG);															//choix de la valeure des jockers(si il y en a)
		Console.println("\nTOUR DU JOUEUR 2");
		Console.couleurFont ( CouleurConsole.ROUGE );
		Exercice7_SAE.Jocker(serpentJ2, LONG);													//FIN PHASE DE JEU
		Console.normal();
		
		Console.println("Affichages des serpents de fin :");									//affichage des serpents terminés
		Console.println("Joueur 1 :\n" + CouleurConsole.VERT.getFont() + Exercice7_SAE.AfficherSerpent(serpentJ1));
		Console.normal();
		Console.println("Joueur 2 :\n" + CouleurConsole.ROUGE.getFont() + Exercice7_SAE.AfficherSerpent(serpentJ2));
		Console.normal();
		
		Console.println(Exercice7_SAE.AfficherScore(score));									//affichage du tableau de score
		
		Console.println("\nCalcul des points du joueur 1 :");									//affichage score joueur 1
		scoreJ1 = Exercice7_SAE.ComptagePoint(serpentJ1, LONG, score);							//comptage du score final du joueur 1
		Console.println("Score final : " + scoreJ1);
		
		Console.println("\nCalcul des points du joueur 2 :");									//affichage score joueur 2
		scoreJ2 = Exercice7_SAE.ComptagePoint(serpentJ2, LONG, score);							//comptage du score final du joueur 2
		Console.println("Score final : " + scoreJ2);
		
		if (scoreJ1 == scoreJ2)																	//choix du gagnant
		{
			Console.println("\nEGALITE");
		}
		else
		{
			if (scoreJ1 < scoreJ2)
			{
				Console.println("\nVICTOIRE DU JOUEUR 2");
			}
			else
			{
				Console.println("\nVICTOIRE DU JOUEUR 1");
			}
		}																						//FIN
	}
	private static short[] ConfigurerScore()
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/ 
		short[]	tab;
		short	saisie;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		Console.println("A quel mode de jeu souhaitez-vous jouer ? (normal : 1 / avance : 2)");
		saisie = Clavier.lire_short();
		while ((saisie != 1 ) && (saisie != 2))
		{
			Console.println("Valeur incorrect");
			Console.println("A quel mode de jeu souhaitez-vous jouer ? (normal : 1 / avance : 2)");
			saisie = Clavier.lire_short();
		}

		if (saisie == 1)
		{
			tab = new short[] {0,1,3,5,7,9,11,15,20,25,30,35,40,50,60,70,85,100,150,300};
		}
		else
		{
			tab = new short[] {0,1,3,5,7,3,11,15,20,25,30,20,40,50,60,70,50,100,150,300};
		}
		return tab;
	}
	private static String AfficherScore(short[] tab)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/
		String	score;
		short	cpt;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		score  = "+-----------------------+\n";
		score += "|	>>	+	|\n";
		cpt = 0;
		while (cpt < tab.length)
		{
			score += "|	" +(cpt+1) + "	+" + tab[cpt] + "	|\n";
			cpt++;
		}
		score += "+-----------------------+";
		return score;
	}
	private static short[] RemplirSerpentVide(final short TAILLE)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/ 
		short[]	tab;
		short	cpt;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		tab = new short[TAILLE];
		cpt = 0;
		while (cpt < TAILLE)
		{
			tab[cpt] = 0;
			cpt++;
		}
		
		return tab;
	}
	private static String AfficherSerpent(short[] tab)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/
		String	serpent;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		serpent  = "      -----\n";
		serpent += "    / O     \\--+-01-+-02-+-03-+    +-09-+-10-+-11-+    +-17-+-18-+-19-+\n";
		serpent += "====           | " + String.format("%2d", tab[0]) + " | " + String.format("%2d", tab[1]) + " | " + String.format("%2d", tab[2]) + " |    | " + String.format("%2d", tab[8]) + " | " + String.format("%2d", tab[9]) + " | " + String.format("%2d", tab[10]) + " |    | " + String.format("%2d", tab[16]) + " | " + String.format("%2d", tab[17]) + " | " + String.format("%2d", tab[18]) + " |\n";
		serpent += "    \\ O     /--+----+----+-04-+    +-08-+----+-12-+    +-16-+----+-20-+\n";
		serpent += "      -----              | " + String.format("%2d", tab[3]) + " |    | " + String.format("%2d", tab[7]) + " |    | " + String.format("%2d", tab[11]) + " |    | " + String.format("%2d", tab[15]) + " |    | " + String.format("%2d", tab[19]) + " |\n";
		serpent += "                         +-05-+-06-+-07-+    +-13-+-14-+-15-+    +----+\n";
		serpent += "                         | " + String.format("%2d", tab[4]) + " | " + String.format("%2d", tab[5]) + " | " + String.format("%2d", tab[6]) + " |    | " + String.format("%2d", tab[12]) + " | " + String.format("%2d", tab[13]) + " | " + String.format("%2d", tab[14]) + " |     \\  /\n";
		serpent += "                         +----+----+----+    +----+----+----+      \\/\n";
		
		return (String) serpent;
	}
	private static short[] RemplirPiocheNormal(short[] nbVal)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/ 
		short[]	tab;
		short	cpt;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		tab = new short[40];
		
		tab[0] = -1;
		nbVal[0]++;
		
		cpt = 1;
		while (cpt <= 30)
		{
			if ((cpt >= 11) && (cpt <= 19))
			{
				tab[nbVal[0]] = cpt;
				nbVal[0]++;
				tab[nbVal[0]] = cpt;
				nbVal[0]++;
			}
			else
			{
				tab[nbVal[0]] = cpt;
				nbVal[0]++;
			}
			cpt++;
		}
		return tab;
	}
	private static short[] RemplirPiocheEntree(short[] nbVal, String argument)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/ 
		short[]	tab;
		short	cpt;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		tab = new short[20];
		
		cpt = 0;
		while (cpt < (argument.length() / 2))
		{
			tab[nbVal[0]] = Short.parseShort((argument.charAt(cpt*2))+""+(argument.charAt((cpt*2)+1)));
			nbVal[0]++;
			
			cpt++;
		}
		return tab;
	}
	private static short Piocher(short[] sac, short[] nbVal)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/
		short	indice, val, retenu;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		indice			= (short)(Math.random() * nbVal[0]);
		retenu			= sac[nbVal[0]-1];
		val				= sac[indice];
		sac[nbVal[0]-1]	= val;
		sac[indice]		= retenu;

		nbVal[0]--;
		return val;
	}
	private static void Tour(short[] tab, short TAILLE, short jeton, short[] nbVal)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/
		boolean	choixCase;
		short	choix, val;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		choixCase = true;								//choix case
		while (choixCase)
		{
			Console.print("Choisissez dans quelle case vous souhaitez la placer : ");
			choix = Clavier.lire_short();
			if (choix >= 1 && choix <= TAILLE)
			{
				if (tab[choix-1] == 0)
				{
					tab[choix-1] = jeton;
					choixCase = false;	
				}
				else
				{	
					Console.println("Cette case est déja prise veuillez en choisir une autre");
				}
			}
			else
			{
				Console.println("Cette case n'existe pas veuillez en choisir une autre");
			}
		}
	}
	private static void Jocker(short[] tab, short TAILLE)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/
		short	cpt, ind, saisie;
		boolean	choixJocker;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		cpt = 0;
		ind = -1;
		while (cpt < TAILLE)
		{
			if (tab[cpt] == -1)
			{
				ind = cpt;
			}
			cpt++;
		}
		
		if (!(ind == -1))
		{
			Console.println(Exercice7_SAE.AfficherSerpent(tab));								//affichage serpent
			Console.normal();
			
			choixJocker  = true;
			while (choixJocker)
			{
				Console.print("Par quelle valeur souhaitez-vous remplacer le jocker : ");
				saisie = Clavier.lire_short();
				if ((saisie >= 1 ) && (saisie <= 30))
				{
					tab[ind] = saisie;
					choixJocker = false;
				}
				else
				{
					Console.println("Valeur incorrect");
				}
			}
		}
		else
		{
			Console.normal();
			Console.println("Aucun jocker present dans le serpent");
		}
	}
	private static short ComptagePoint(short[] tab, short TAILLE, short[] tabScore)
	{
		/*---------------*/
		/*   Données     */
		/*---------------*/

		/*---Variable----*/
		short cpt, derniereVal, longSuite, scoreFinal;

		/*---------------*/
		/* Instructions  */
		/*---------------*/
		
		cpt = longSuite = 1;
		derniereVal = tab[0];
		Console.print("	" + derniereVal + " ");
		scoreFinal = 0;
		while (cpt < TAILLE)
		{
			if(tab[cpt] > derniereVal)
			{
				longSuite++;
				derniereVal = tab[cpt];
				Console.print(derniereVal + " ");
			}
			else
			{
				Console.print( ": " + tabScore[longSuite-1] + " points\n");

				scoreFinal += tabScore[longSuite-1];
				longSuite = 1;
				derniereVal = tab[cpt];

				Console.print("	" + derniereVal + " ");
			}
			cpt++;
		}
		Console.print(": " + tabScore[longSuite-1] + " points\n");

		scoreFinal += tabScore[longSuite-1];
		return scoreFinal;
	}
}