--Afficher tous les auteurs

SELECT *
FROM Auteur ;