--Afficher tous les titres des bd que le client 7 a acheté

SELECT	titre
FROM	BD b JOIN LigneVente l ON b.isbn = l.isbn
WHERE	numVente IN (   SELECT numVente
                        FROM   Vente
                        WHERE  numClient = 7  );
