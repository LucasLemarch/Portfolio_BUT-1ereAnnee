--Afficher le nom des clients qui ont acheté une bd de la série ‘Astérix le gaulois’

SELECT  nomclient
FROM    client c JOIN vente v ON c.numclient = v.numclient
WHERE   numvente IN (   SELECT  numvente
                        FROM    LigneVente
                        WHERE   isbn = (    SELECT  isbn
                                            FROM    BD b JOIN serie s
                                                    ON b.numserie = s.numserie
                                            WHERE   titre = 'Astérix le gaulois'));
