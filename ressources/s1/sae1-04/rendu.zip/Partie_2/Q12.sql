--Afficher le titre des bd qui ont comme numéro de scénariste principal 7 et numéro de dessinateur principal 5

/*  A : titre des bd qui ont comme numéro de scénariste principal 7
    B : titre des bs qui ont comme numéro de dessinateur principal 5
            A INTERSECT B                                           */


SELECT  titre
FROM    bd
WHERE   numScenariste = 7

INTERSECT

SELECT  titre
FROM    bd
WHERE   numDessinateur = 5;
