--Augmenter le prix des BD de 1 euro

UPDATE  BD
SET     prixActuel = prixActuel + 1;
