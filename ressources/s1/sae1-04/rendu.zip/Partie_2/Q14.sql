--Supprimer la BD nommé le bois sauvage

DELETE FROM BD
WHERE titre = 'le bois sauvage' ;
