--Renommer l’attribut titre de la table BD en nomBD

ALTER TABLE BD
RENAME COLUMN titre to nomBD;
