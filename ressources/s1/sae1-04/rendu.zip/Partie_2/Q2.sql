--Afficher le nom des auteurs qui habitent en France.

SELECT  nomAuteur
FROM    Auteur 
WHERE   Pays = 'France' ;