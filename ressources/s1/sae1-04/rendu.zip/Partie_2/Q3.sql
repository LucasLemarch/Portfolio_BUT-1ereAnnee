--Afficher les noms des clients dont le nom commence par un T.

SELECT  nomClient
FROM    Client
WHERE   nomClient LIKE 'T%';