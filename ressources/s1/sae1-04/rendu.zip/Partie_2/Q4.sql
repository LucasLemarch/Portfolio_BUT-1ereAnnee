--Afficher les numéros ISBN des Livres dont le prix actuel est supérieur à 15

SELECT	isbn 
FROM	BD 
WHERE	prixActuel > 15;
