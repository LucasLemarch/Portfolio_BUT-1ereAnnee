--Afficher les numéros de tome et les titres des BD dont le prix est inférieur à la moyenne des prix

SELECT  numtome, titre
FROM	BD 
WHERE	prixActuel < (	SELECT AVG (prixActuel)
                        FROM BD				    );
