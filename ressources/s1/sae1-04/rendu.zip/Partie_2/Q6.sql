--Afficher les titres des BD qui ont été rédigés par Goscinny René

SELECT  titre
FROM	BD b JOIN Auteur a ON b.numScenariste = a.numAuteur
WHERE	nomAuteur = 'Goscinny' AND
        prenomAuteur = 'René';
