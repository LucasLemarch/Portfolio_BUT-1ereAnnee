--Afficher le nombre de bd

SELECT	count(*)
FROM	BD;
