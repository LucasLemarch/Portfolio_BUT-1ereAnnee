--Afficher les noms et numéro de téléphone des clients qui ont acheté plusieurs exemplaires d’une bd en un achat

SELECT  c.numclient, c.numtelclient
FROM	Client c    JOIN Vente v        ON c.numClient = v.numClient
                    JOIN LigneVente l   ON l.numVente = v.numVente
WHERE	quantite > 1;
