--Afficher les séries qui n’ont pas comme dessinateur et scénariste principaux le même auteur

/*  A : Toutes les séries
    B : Toutes les qui n’ont pas comme dessinateur et scénariste principaux le même auteur
            A EXCEPT B								                                    	*/

SELECT	*
FROM 	serie

EXCEPT

SELECT  *
FROM	serie
WHERE	numserie IN (   SELECT	numserie
				        FROM	BD
				        WHERE	numDessinateur = numScenariste ) ;
    