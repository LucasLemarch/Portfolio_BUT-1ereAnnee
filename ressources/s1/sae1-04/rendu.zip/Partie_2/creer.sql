--Nous supprimons dans le cas où elles-existent toutes les éventuelles tables avec les mêmes nom que celle que nous souhaitons créer
DROP TABLE ligneVente;
DROP TABLE vente;
DROP TABLE client;
DROP TABLE bd;
DROP TABLE auteur;
DROP TABLE serie;
DROP TABLE editeur;

/*créer une relation correspondant au schéma de relation suivant :
	Editeur(numEditeur, nomEditeur, adresseEditeur, numTelEditeur, mailEditeur)
	numEditeur est la clé primaire de type sérial pour que cette valeur soit toujours différente sans avoir à l’entrée.
	Tous les autres attributs sont de type texte.
    nomEditeur et adresseEditeur sont obligatoires
*/
CREATE TABLE Editeur(
numEditeur 		serial PRIMARY KEY,
nomEditeur 		text NOT NULL,
adresseEditeur 	text NOT NULL,
numTelEditeur 	text,
mailEditeur 	text);

/*créer une relation correspondant au schéma de relation suivant :
	Serie(numSerie, nomSerie, numEditeur#)
	numClient est la clé primaire de type serial.
	L’attribut nomSerie est de type texte.
    numEditeur est la clé étrangère de l’attribut numEditeur de la table Editeur.
	nomClient et numEditeur sont obligatoires.
*/
CREATE TABLE Serie(
numSerie 	serial PRIMARY KEY,
nomSerie 	text NOT NULL,
numEditeur	int REFERENCES Editeur(numEditeur) );


/*créer une relation correspondant au schéma de relation suivant :
	Auteur(numAuteur, nomAuteur, prenomAuteur, dteNaissAuteur, dteDecesAuteur, pays)
	numAuteur est la clé primaire de type serial .
	Les attributs nomAuteur, prenomAuteur et pays sont de type texte.
	Les attributs dteNaissAuteur et dteDecesAuteur sont de type date.
	nomAuteur et pays sont obligatoires.
*/
CREATE TABLE Auteur(
numAuteur 		serial PRIMARY KEY,
nomAuteur 		text NOT NULL,
prenomAuteur 	text,
dteNaissAuteur 	date,
dteDecesAuteur 	date,
pays		 	text NOT NULL ); 

/*créer une relation correspondant au schéma de relation suivant :
	BD(numSerie, numTome, titre, isbn, depotLegal, numScenariste#, numDessinateur#, numSerie#, prixActuel)
	isbn est la clé primaire de type text.
	Les attributs titre et depotLegal sont de type texte.
	L’attribut prixActuel est de type réel pour prendre en compte les centimes.
	L’attribut numTome est de type entier.
    numSerie est la clé étrangère de l’attribut numSerie de la table Serie.
	numScenariste est la clé étrangère de l’attribut numAuteur de la table Auteur.
	numDessinateur est la clé étrangère de l’attribut numAuteur de la table Auteur.
	prixActuel, depotLegal, numScenariste, numDessinateur et numSerie sont obligatoires.
*/
CREATE TABLE BD(
numSerie 		int REFERENCES Serie(numSerie),
numTome		    int,
titre 			text, 
isbn 			text PRIMARY KEY,
depotLegal		text NOT NULL,
numScenariste 	int REFERENCES Auteur(numAuteur),
numDessinateur 	int REFERENCES Auteur(numAuteur),
prixActuel 		float NOT NULL );

/*créer une relation correspondant au schéma de relation suivant :
	Client(numClient, nomClient, nomTelClient, mailClient)
	numClient est la clé primaire de type sérial .
	Tous les autres attributs sont de type texte.
	nomClient est obligatoire.
*/
CREATE TABLE Client ( 
numClient   	serial PRIMARY KEY,
nomClient 	    text NOT NULL,
numTelClient 	text,
mailClient 	    text);

/*créer une relation correspondant au schéma de relation suivant :
	Vente(numVente, dteVente, numClient#)
	numVente est la clé primaire de type serial .
	dateVente est de type date, si lors d’une insertion aucune date n’est rentré ce sera la date de l’insertion qui sera rentrée
	numClient est la clé étrangère de l’attribut numClient de la table Client.
	numClient est obligatoire.
*/
CREATE TABLE Vente(
numVente 	serial PRIMARY KEY,
dteVente 	date   default CURRENT_DATE,
numClient   int    REFERENCES Client(numClient) );

/*créer une relation correspondant au schéma de relation suivant :
	LigneVente(isbn#, numVente#, prixVente, quantité)
	isbn est la clé étrangère de l’attribut içsbn de la table BD.
    numVente est la clé étrangère de l’attribut numVente de la table Vente.
	Les attributs prixVente et quantite sont de type entier.
	isbn et numVente forment la clé primaire.
	isbn, numVente, prixVente et qu sont obligatoires.
*/
CREATE TABLE LigneVente(
isbn        text   references BD(isbn),
numVente    int    references Vente(numVente),
prixVente   float  NOT NULL,
quantite    int    NOT NULL,
primary key (isbn, numVente));