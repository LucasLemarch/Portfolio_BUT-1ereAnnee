/*insertion dans une table correspondant au schéma de relation suivant :
	Editeur(numEditeur, nomEditeur, adresseEditeur, numTelEditeur, mailEditeur)
	numEditeur n'est pas renseigné car il est de type serial et se renseigne tout seul.
	Toutes les autres attributs sont renseigné avec des simple quotes car ils sont de type text.
    numTelEditeur et mailEditeur peuvent-êtres null.
*/
Insert into Editeur (nomEditeur, adresseEditeur, numTelEditeur, mailEditeur)
values ('Delcourt'               , '8 rue Léon Jouhaux, 75010 Paris'                   , '01 56 03 92 20', 'accueil-paris@groupedelcourt.com'),
	   ('Dargaud'                , '57 rue Gaston Tessier 75019 PARIS'                 , '01 53 26 32 32', 'contact@dargaud.fr'),
	   ('Hélium'                 , '18, rue Séguier, 75006 Paris'                      , '01 55 42 65 14', 'info@helium-editions.fr'),
	   ('Les Humanoïdes Associés', '24, avenue Philippe Auguste 750111 Paris'          , '01 49 29 88 88', 'editorial@humano.com'),
	   ('Pika Edition'           , '58, rue Jean-Bleuzen CS 70007 92178 Vanves Cedex'  , '01 43 92 30 00', 'mypika@pika.fr'),
	   ('Bamboo Edition'         , '290 route des Allogneraies 71850 Charnay-les-Mâcon', '03 85 34 99 09', 'c.loiselet@bamboo.fr'),
	   ('Vents d Ouest'          , '31/33, rue Ernest-Renan, 92130 Issy-les-Moulineaux', '04 50 27 85 41', 'ventsdouest@videotron.ca'),
	   ('Lombard (Le)'           , '57, rue Gaston TessierF - 75019 Paris'             , null            , 'info@lombard.be'),
	   ('Tonkam'                 ,'99, rue du faubourg-du-temple 75010 Paris'          , '01 40 40 90 80' , null);

/*insertion dans une table correspondant au schéma de relation suivant :
	Serie(numSerie, nomSerie, numEditeur#)
	numSerie n'est pas renseigné car il est de type serial et se renseigne tout seul.
	nomSerie est renseigné avec des simple quotes car il est de type text.
    numEditeur est renseigné avec un nombre entier car il est de type int.
    numEditeur est la clé étrangère de l’attribut numEditeur de la table Editeur.
*/
Insert into Serie (nomSerie,numEditeur)
VALUES	('vent dans les Saules (Le)'			,1),
		('Astérix le gaulois'					,2),
		('L Auberge Rouge'						,2),
		('Les couleurs de l infamie'			,2),
		('L histoire de Sayo'					,2),
		('Les brumes de Sapa'					,1),
		('Marshmalone'							,3),
		('Résau Bombyce (Le)'					,4),
		('Dans un recoin de ce monde'			,5),
		('L histoire des 3 Adolf'				,9),
		('L Adoption'							,6),
		('Damnés de la terre associés (Les)'	,1),
		('Peter Pan'							,7),
		('Complainte des landes perdues'		,2),
		('Aventures de Blake et Mortimer (Les)'	,8);

/*insertion dans une table correspondant au schéma de relation suivant :
	Auteur(numAuteur, nomAuteur, prenomAuteur, dteNaissAuteur, dteDecesAuteur, pays)
	numAuteur n'est pas renseigné car il est de type serial et se renseigne tout seul.
	Toutes les autres attributs sont renseigné avec des simple quotes car ils soit de type text, soit de type date.
    prenomAuteur, dteNaissAuteur et dteDecesAuteur peuvent-êtres null.
*/
INSERT INTO Auteur ( nomAuteur, prenomAuteur, dteNaissAuteur, dteDecesAuteur, pays)
VALUES  ('Aubin',   	'Antoine',  	'08/08/1967',   	null,       	'France' ),
    	('Benoit',  	'Ted',      	'25/07/1947',   	'30/09/2016',   'France' ),
    	('Berserik',	'Teun',     	'09/01/1955',   	null,       	'Pays-bas' ),
    	('Cailleaux',   'Christian',	'01/01/1967',   	null,       	'France' ),
    	('Cécil',    	null,      		'18/05/1966',   	null,       	'France' ),
    	('Conrad',  	'Didier',   	'08/08/1959',   	null,       	'France' ),
    	('Corbeyran',   'Eric',     	'14/12/1964',   	null,       	'France' ),
    	('Cuveele', 	'Delphine',  	null,          		null,       	'France' ),
    	('Delaby',  	'Philippe', 	'21/01/1961',   	'28/01/2014',   'Belgique'),
    	('Dufaux',  	'Jean',     	'07/06/1949',   	null,       	'Belgique'),
    	('Ferri',   	'Jean-Yves',	'25/04/1959',   	null,       	'France'),
    	('Garel',   	'Roland',   	'26/08/1930',   	'04/02/2015',   'France'),
    	('Golo',     	null,     	 	'26/08/1948',   	null,       	'France'),
    	('Goscinny',	'René',     	'14/08/1926',   	'05/11/1977',   'France'),
    	('Gossery', 	'Albert',   	'01/01/1913',   	'06/01/2008',   'Egypte'),
    	('Jacobs',  	'Edgar Pierre', '30/03/1904',   	'20/02/1987',   'Belgique'),
    	('Juillard',	'André',    	'09/06/1948',   	null,       	'France'),
    	('Kouno',   	'Fumiyo',   	'09/01/1968',   	null,       	'Japon'),
    	('Lécureux',	'Roger',    	'07/04/1925',   	'31/12/1999',   'France'),
    	('Loisel',  	'Régis',    	'12/04/1951',   	null,       	'France'),
    	('Masi',    	'Giovanni', 	'01/01/1980',   	null,       	'Italie'),
    	('Monin',   	'Arno',     	'11/06/1981',   	null,       	'France'),
    	('Plessix', 	'Michel',   	'11/10/1959',   	'21/08/2017',   'France'),
    	('Rosinski',	'Grzegorz', 	'08/03/1941',   	null,       	'Pologne'),
    	('Séchan',  	'Lolita',   	'08/09/1980',   	null,       	'France'),
    	('Sente',   	'Yves',     	'17/01/1964',   	null,       	'Belgique'),
    	('Sterne',  	'René',     	'25/08/1952',   	'15/11/2006',   'Belgique'),
    	('Tezuka',  	'Osamu',    	'11/03/1928',   	'09/02/1989',   'Japon'),
    	('Tillier', 	'Béatrice', 	'18/09/1972',   	null,       	'France'),
    	('Tronchet',	null,       	'29/09/1958',   	null,       	'France'),
    	('Uderzo',  	'Albert',   	'25/04/1927',   	'24/03/2020',   'France'),
    	('Van Hamme',   'Jean',     	'16/01/1939',   	null,       	'Belgique'),
    	('Watanabe',	'Yoshiko',  	null,           	null,       	'Japon');

/*insertion dans une table correspondant au schéma de relation suivant :
	BD(numSerie, numTome, titre, isbn, depotLegal, numScenariste#, numDessinateur#, numSerie#, prixActuel)
	titre, depotLegal et isbn sont renseigné avec des simple quotes car ils sont de type text.
    numSerie, numTome, numScenariste et numDessinateur sont renseigné avec un nombre entier car ils sont de type int.
    prixActuel est renseigné avec un réel car il est de type float.
    numSerie est la clé étrangère de l’attribut numSerie de la table Serie.
	numScenariste est la clé étrangère de l’attribut numAuteur de la table Auteur.
	numDessinateur est la clé étrangère de l’attribut numAuteur de la table Auteur.
    numTome et titre peuvent-êtres null.
*/		
INSERT INTO BD (numSerie, numTome, titre, depotLegal, isbn, numScenariste, numDessinateur, prixActuel)
VALUES
( 1, 1,		'Le bois sauvage',                                       '10/1996', '978-2-7560-2538-4',     23, 23, 15.5),
( 1, 2,		'Auto, Crapaud, Blaireau',                               '01/1998', '978-2-7560-2539-1',     23, 23, 15.5),
( 1, 3,		'L échapée belle',                                       '08/1999', '978-2-7560-2540-7',     23, 23, 15.5),
( 1, 4,		'Foutoir au manoir',                                     '11/2001', '978-2-7560-2541-4',     23, 23, 15.5),
( 2, 1,		'Astérix le gaulois',                                    '07/1961', '978-2-2050-0096-2',     14, 31, 12),
( 2, 2,		'La serpe d or',                                         '07/1962', '978-2-0121-0134-0',     14, 31, 12),
( 2, 3,		'Astérix et les Goths',                                  '07/1963', '978-2-0121-0135-7',     14, 31, 12),
( 2, 4,		'Astérix Gladiateur',                                    '07/1964', '978-2-0121-0136-4',     14, 31, 12),
( 2, 5,		'Le tour de Gaule d Astérix',                            '01/1965', '978-2-0121-0137-1',     14, 31, 12),
( 2, 6,		'Astérix et Cléopâtre',                                  '07/1965', '978-2-0121-0138-8',     14, 31, 12),
( 2, 7,		'Le combat des chefs',                                   '01/1966', '978-2-0121-0139-5',     14, 31, 12),
( 2, 8,		'Astérix chez les Bretons',                              '01/1966', '978-2-0121-0140-1',     14, 31, 12),
( 2, 9,		'Astérix et les Normands',                               '07/1966', '978-2-0121-0141-8',     14, 31, 12),
( 2, 10,	'Astérix Légionnaire',                                   '10/1966', '978-2-0121-0142-5',     14, 31, 12),
( 2, 11,	'Le bouclier Arverne',                                   '07/1967', '978-2-0121-0143-2',     14, 31, 12),
( 2, 12,	'Astérix aux jeux Olympiques',                           '01/1968', '978-2-0121-0144-9',     14, 31, 12),
( 2, 13,	'Astérix et le chaudron',                                '07/1968', '978-2-0121-0145-6',     14, 31, 12),
( 2, 14,	'Astérix en Hispanie',                                   '01/1969', '978-2-0121-0146-3',     14, 31, 12),
( 2, 15,	'La zizanie',                                            '10/1969', '978-2-0121-0147-0',     14, 31, 12),
( 2, 16,	'Astérix chez les Helvètes',                             '04/1970', '978-2-0121-0148-7',     14, 31, 12),
( 2, 17,	'Le domaine des dieux',                                  '10/1970', '978-2-0121-0149-4',     14, 31, 12),
( 2, 18,	'Les lauriers de César',                                 '10/1971', '978-2-0121-0150-0',     14, 31, 12),
( 2, 19,	'Le devin',                                              '01/1972', '978-2-0121-0151-7',     14, 31, 12),
( 2, 20,	'Astérix en Corse',                                      '10/1972', '978-2-0121-0152-4',     14, 31, 12),
( 2, 21,	'Le cadeau de César',                                    '04/1973', '978-2-0121-0153-1',     14, 31, 12),
( 2, 22,	'La grande traversée',                                   '07/1974', '978-2-0121-0154-8',     14, 31, 12),
( 2, 23,	'Obélix et compagnie',                                   '04/1975', '978-2-0121-0155-5',     14, 31, 12),
( 2, 24,	'Astérix chez les Belges',                               '04/1976', '978-2-0121-0156-2',     14, 31, 12),
( 2, 25,	'Le Grand Fossé',                                        '01/1979', '978-2-8649-7000-2',     14, 31, 12),
( 2, 26,	'L odyssée d Astérix',                                   '04/1980', '978-2-8649-7004-0',     14, 31, 12),
( 2, 27,	'Le fils d Astérix',                                     '10/1981', '978-2-8649-7011-8',     14, 31, 12),
( 2, 28,	'Astérix chez Rahãzade',                                 '10/1983', '978-2-8649-7020-0',     14, 31, 12),
( 2, 29,	'La rose et le glaive',                                  '10/1987', '978-2-8649-7053-8',     14, 31, 12),
( 2, 30,	'La galère d Obélix',                                    '10/1991', '978-2-8649-7096-5',     14, 31, 12),
( 2, 31,	'Astérix et Latraviata',                                 '07/1996', '978-2-8649-7143-6',     14, 31, 12),
( 2, 32,	'Astérix et la rentrée gauloise',                        '03/2001', '978-2-8649-7153-5',     14, 31, 12),
( 2, 33,	'Le ciel lui tombe sur la tête',                         '01/1993', '978-2-8649-7170-2',     14, 31, 12),
( 2, 34,	'L Anniversaire d Astérix & Obélix - Le livre d Or',     '10/2005', '978-2-8649-7230-3',     14, 31, 12),
( 2, 35,	'Astérix chez les Pictes',                               '10/2009', '978-2-8649-7266-2',     14, 31, 12),
( 2, 36,	'Le papyrus de César',                                   '10/2013', '978-2-8649-7271-6',     14, 31, 12),
( 2, 37,	'Astérix et la Transitalique',                           '10/2015', '978-2-8649-7327-0',     14, 31, 12),
( 2, 38,	'La Fille de Vercingétorix',                             '10/2017', '978-2-8649-7342-3',     14, 31, 12),
( 2, 39,	'Astérix et le Griffon',                                 '10/2019', '978-2-8649-7349-2',     14, 31, 12),
( 3, 1,		'L Auberge Rouge',                                       '10/2021', '978-2-0918-9263-4',     14, 31, 12),
( 4, 1,		'Les couleurs de l infamie',                             '04/1969', '978-2-2050-5419-4',     15, 13, 12),
( 5, 1,		'L histoire de Sayo',                                    '03/2003', '978-2-5050-1037-1',     21, 33, 12),
( 6, 1,		'Les brumes de Sapa',                                    '01/2011', '978-2-7560-5126-0',     25, 25, 18),
( 7, 1,		'Marshmalone',                                           '10/2016', '978-2-3585-1036-3',     25, 25, 18),
( 8, 1,		'Papillons de nuit',                                     '09/2010', '978-2-7316-2306-2',     7, 5, 15.75),
( 8, 2,		'Monsieur lune',                                         '11/1999', '978-2-7316-2307-9',     7, 5, 15.75),
( 8, 3,		'Stigmates',                                             '12/2002', '978-2-7316-1723-8',     8, 7, 15.75),
( 9, 1,		null,                                                    '11/2010', '978-2-5050-6976-8',     18, 18, 11.5),
( 9, 2,		null,                                                    '08/2013', '978-2-3763-2021-0',     18, 18, 11.5),
(10, 1,		null,                                                    '12/2013', '978-2-9126-2829-9',     28, 28, 18.4),
(10, 2,		null,                                                    '07/1998', '978-2-9126-2830-5',     28, 28, 18.4),
(10, 3,		null,                                                    '12/1998', '978-2-9126-2831-2',     28, 28, 18.4),
(10, 4,		null,                                                    '03/1999', '978-2-9126-2832-9',     28, 28, 18.4),
(11, 1,		'Qinaya',                                                '07/1999', '978-2-8189-3603-0',     22, 22, 15.9),
(11, 2,		'La Garúa',                                              '05/2016', '978-2-8189-4170-6',     22, 22, 15.9),
(11, 3,		'Wajdi',                                                 '06/2017', '978-2-8189-7689-0',     22, 22, 15.9),
(12, 1,		'Stars d un jour…',                                      '10/2021', '978-2-9061-8707-8',     30, 30, 13.5),
(12, 2,		'Stars toujours !',                                      '10/1987', '978-2-9061-8719-1',     30, 30, 13.5),
(12, 3,		'Jours de stars',                                        '11/1998', '978-2-9061-8761-0',     30, 30, 13.5),
(12, 4,		'Au bonheur des drames',                                 '03/1991', '978-2-2260-7457-7',     30, 30, 13.5),
(12, 5,		'Les rois du rire',                                      '09/1994', '978-2-2260-8516-0',     30, 30, 13.5),
(12, 6,		'Pauvres mais fiers',                                    '10/1996', '978-2-2261-1485-3',     30, 30, 13.5),
(13, 1,		'Londres',                                               '11/2000', '978-2-7493-0701-5',     20, 20, 14),
(13, 2,		'Opikanoba',                                             '11/1990', '978-2-7493-0702-2',     20, 20, 14),
(13, 3,		'Tempête',                                               '09/1992', '978-2-7493-0703-9',     20, 20, 14),
(13, 4,		'Mains rouges',                                          '11/1994', '978-2-7493-0704-6',     20, 20, 14),
(13, 5,		'Crochet',                                               '09/1996', '978-2-7493-0705-3',     20, 20, 14),
(13, 6,		'Destins',                                               '01/2002', '978-2-7493-0706-0',     20, 20, 14),
(14, 1,		'Sioban',                                                '10/2004', '978-2-5050-0539-1',     10, 24, 14.5),
(14, 2,		'Blackmore',                                             '01/1993', '978-2-5050-0540-7',     10, 24, 14.5),
(14, 3,		'Dame Gerfaut',                                          '01/1994', '978-2-5050-0541-4',     10, 24, 14.5),
(14, 4,		'Kyle of Klanach',                                       '01/1996', '978-2-5050-0542-1',     10, 24, 14.5),
(14, 5,		'Moriganes',                                             '10/1998', '978-2-5050-0478-3',     10, 9, 14.5),
(14, 6,		'Le Guinea Lord',                                        '10/2004', '978-2-5050-0464-6',     10, 9, 14.5),
(14, 7,		'La Fée Sanctus',                                        '10/2008', '978-2-5050-1387-7',     10, 9, 14.5),
(14, 8,		'Sill Valt',                                             '06/2012', '978-2-5050-1979-4',     10, 9, 14.5),
(14, 9,		'Tête noire',                                            '11/2014', '978-2-5050-6350-6',     10, 29, 14.5),
(14, 10	,	'La pluie',                                              '10/2015', '978-2-5050-6399-5',     10, 29, 14.5),
(15, 1,		'Le secret de lespadon 1',                               '01/2019', '978-2-8709-7165-9',     16, 16, 15.9),
(15, 2,		'Le secret de lespadon 2',                               '01/1984', '978-2-8709-7166-6',     16, 16, 15.9),
(15, 3,		'Le secret de lespadon 3',                               '01/1985', '978-2-8709-7167-3',     16, 16, 15.9),
(15, 4,		'Le Mystère de la grande pyramide 1',                    '01/1986', '978-2-8709-7168-0',     16, 16, 15.9),
(15, 5,		'Le Mystère de la grande pyramide 2',                    '01/1987', '978-2-8709-7169-7',     16, 16, 15.9),
(15, 6,		'La marque Jaune',                                       '01/1987', '978-2-8709-7170-3',     16, 16, 15.9),
(15, 7,		'L énigmne de l atlantide',                              '01/1987', '978-2-8709-7171-0',     16, 16, 15.9),
(15, 8,		'S.O.S. Météores',                                       '01/1988', '978-2-8709-7172-7',     16, 16, 15.9),
(15, 9,		'Le piège diabolique',                                   '01/1989', '978-2-8709-7173-4',     16, 16, 15.9),
(15, 10,	'L affaire du collier',                                  '01/1990', '978-2-8709-7174-1',     16, 16, 15.9),
(15, 11,	'Les 3 formules du professeur Sato 1',                   '01/1991', '978-2-8709-7175-8',     16, 16, 15.9),
(15, 12,	'Les 3 formules du professeur Sato 2',                   '01/2000', '978-2-8709-7176-5',     16, 16, 15.9),
(15, 13,	'L affaire Francis Blake',                               '09/2001', '978-2-8709-7177-2',     32, 2, 15.9),
(15, 16,	'Les Sarcophages du 6ème continent 1',                   '11/2003','978-2-8709-7180-2',     26, 17, 15.9),
(15, 17,	'Les Sarcophages du 6ème continent 2',                   '10/2004', '978-2-8709-7181-9',     26, 17, 15.9),
(15, 18,	'Le Sanctuaire du Gondwana',                             '03/2008', '978-2-8709-7182-6',     26, 17, 15.9),
(15, 19,	'La malédiction des trente deniers 1',                   '11/2009', '978-2-8709-7183-3',     32, 27, 15.9),
(15, 20,	'La malédiction des trente deniers 2',                   '11/2010', '978-2-8709-7184-0',     32, 1, 15.9),
(15, 21,	'Le serment des cinq lords',                             '11/2012', '978-2-8709-7164-2',     26, 17, 15.9),
(15, 22,	'L onde Septimus',                                       '12/2013', '978-2-8709-7189-5',     10, 1, 15.9),
(15, 23,	'Le bâton de Plutarque',                                 '12/2014', '978-2-8709-7193-2',     26, 17, 15.9),
(15, 24,	'Le testament de William S.',                            '11/2016', '978-2-8709-7242-7',     26, 17, 15.9),
(15, 25,	'La valée des immortels 1',                              '11/2018', '978-2-8709-7244-1',     26, 3, 15.9),
(15, 26,	'La valée des immortels 2',                              '11/2019', '978-2-8709-7281-6',     26, 3, 15.9),
(15, 27,	'Le cri du Moloch',                                      '11/2020', '978-2-8709-7292-2',     10, 4, 15.9);

/*insertion dans une table correspondant au schéma de relation suivant :
	Client(numClient, nomClient, nomTelClient, mailClient)
    numClient n'est pas renseigné car il est de type serial et se renseigne tout seul.
	Toutes les autres attributs sont renseigné avec des simple quotes car ils sont de type text.
    numTelClient et mailClient peuvent-êtres null.
*/	
INSERT INTO Client( nomClient, numTelClient, mailClient) VALUES
('Torguesse'  , '03 33 08 67 87', 'mail@lisse.com'),
('Fissile'    , '04 98 04 71 29', 'mail@ange.fr'  ),
('Hauraque'   , '06 37 46 13 75', 'mail@odie.fr'  ),
('Poret'      , '04 04 05 36 45', 'mail@he.fr'    ),
('Menvussa'   , '08 71 72 00 86', 'mail@lisse.com'),
('Timable'    , '06 56 53 01 40', 'mail@limelo.com'),
('Don Devello', '08 78 63 01 68', 'mail@he.fr'   ),
('Ohm        ', '06 17 76 81 86', 'mel@odie.net' ),
('Ginal      ', '08 89 78 48 51', 'mel@ange.fr'  ),
('Hautine    ', '02 75 25 73 17', 'mail@bas.com' ),
('Kament     ', '08 21 24 15 54', null );

/*insertion dans une table correspondant au schéma de relation suivant :
	Vente(numVente, dteVente, numClient#)
    numVente n'est pas renseigné car il est de type serial et se renseigne tout seul.
	dteVente est renseigné avec des simple quotes car il est de type date.
    numClient est renséigné avec un nombre entier car il est de type int.
    numClient est la clé étrangère de l’attribut numClient de la table Client.
    Si dteVente n'est pas renseigné c'est la date du jour qui est entrée.
*/	
Insert into Vente ( dteVente, numClient)
values ( '11/11/2020', 1 ),
	   ( '05/02/2021', 2 ),
	   ( '17/02/2021', 3 ),
	   ( '28/02/2021', 4 ),
	   ( '10/03/2021', 4 ),
	   ( '24/03/2021', 6 ),
	   ( '01/04/2021', 5 ),
	   ( '15/05/2021', 9 ),
	   ( '23/06/2021', 8 ),
	   ( '07/07/2021', 7 ),
	   ( '11/09/2021', 1 ),
	   ( '12/10/2021', 10 ),
	   ( '26/10/2021', 11 ),
	   ( '14/11/2021', 7 ),
	   ( '03/12/2021', 6 );

/*insertion dans une table correspondant au schéma de relation suivant :
	LigneVente(isbn#, numVente#, prixVente, quantité)
	isbn est renseigné avec des simple quotes car il est de type text.
    numVente et quantite sont renséigné avec des nombres entier car il sont de type int.
    prixVente est renseigné avec un réel car il est de type float.
    isbn est la clé étrangère de l’attribut isbn de la table BD.
    numVente est la clé étrangère de l’attribut numVente de la table Vente.
*/	
INSERT INTO  LigneVente (isbn, numVente, prixVente, quantite)
VALUES  ('978-2-7560-2538-4',  1, 15.5 , 2),
        ('978-2-7560-2539-1',  1, 15.5 , 1),
        ('978-2-7560-2540-7',  1, 15.5 , 1),
        ('978-2-7560-2541-4',  1, 15.5 , 1),
        ('978-2-2050-5419-4',  2, 18   , 1),
        ('978-2-0121-0136-4',  3, 12   , 1),
        ('978-2-0121-0137-1',  3, 12   , 1),
        ('978-2-8649-7327-0',  4, 12   , 3),
        ('978-2-3585-1036-3',  5, 18   , 1),
        ('978-2-8709-7292-2',  5, 15.9 , 1),
        ('978-2-2050-0096-2',  6, 12   , 1),
        ('978-2-0121-0136-4',  6, 12   , 1),
        ('978-2-0121-0138-8',  6, 12   , 1),
        ('978-2-8709-7242-7',  7, 15.9 , 1),
        ('978-2-8649-7342-3',  8, 12   , 1),
        ('978-2-8189-7689-0',  8, 15.9 , 1),
        ('978-2-7493-0701-5',  9, 14   , 1),
        ('978-2-5050-0539-1', 10, 14.5 , 1),
        ('978-2-5050-0540-7', 10, 14.5 , 1),
        ('978-2-5050-0541-4', 10, 14.5 , 1),
        ('978-2-5050-0542-1', 10, 14.5 , 1),
        ('978-2-7560-2539-1', 11, 15.5 , 1),
        ('978-2-7560-2540-7', 11, 15.5 , 1),
        ('978-2-7560-2541-4', 11, 15.5 , 1),
        ('978-2-0121-0145-6', 12, 12   , 2),
        ('978-2-0121-0146-3', 12, 12   , 2),
        ('978-2-7316-2306-2', 13, 15.75, 1),
        ('978-2-5050-0478-3', 14, 14.5 , 1),
        ('978-2-5050-0464-6', 14, 14.5 , 1),
        ('978-2-5050-1387-7', 14, 14.5 , 1),
        ('978-2-5050-1979-4', 14, 14.5 , 1),
        ('978-2-5050-6350-6', 14, 14.5 , 1),
        ('978-2-5050-6399-5', 14, 14.5 , 1),
        ('978-2-7316-2306-2', 15, 15.75, 1),
        ('978-2-7316-2307-9', 15, 15.75, 1),
        ('978-2-7316-1723-8', 15, 15.75, 1);
