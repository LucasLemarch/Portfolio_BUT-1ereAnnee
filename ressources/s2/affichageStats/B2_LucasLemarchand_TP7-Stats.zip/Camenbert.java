import javax.swing.*;
import java.awt.Graphics;
import java.awt.Color;

public class Camenbert extends JFrame
{
	private Metier metier;

	public Camenbert()
	{
		this.metier = new Metier();

		int hauteurFenetre = 60 + metier.getNbValeur() * 20;	//on adapte la taille de la page au nombre de valeur à afficher
		if ( hauteurFenetre < 200 )								//on donne une taille minimum pour le camenbert
			 hauteurFenetre = 200;

		this.setTitle("Camenbert");
		this.setSize(300, hauteurFenetre);
		this.setVisible(true);
		
	}

	public void paint(Graphics g)
	{
		Color[] tabColor = new Color[] { Color.RED  , Color.BLUE, Color.PINK  , Color.CYAN,
		                                 Color.GREEN, Color.GRAY, Color.ORANGE, Color.YELLOW };

		super.paint(g);
		
		int angle;
		int val = 0;
		for (int i = 0 ; i < this.metier.getNbValeur() ; i++)
		{
			g.setColor(tabColor[i%8]);
			g.fillRect(200, 50 + (i*20), 10, 10);
			g.drawString("" + this.metier.getValeur(i),215,59 + (i*20));

			angle = (int) Math.round(this.metier.getFrequence(i) * 360.0);

			if (i == this.metier.getNbValeur() - 1)								//pour forcément arriver à 360°
				g.fillArc(25, 50, 125, 125, val, 360 - val);
			else
				g.fillArc(25, 50, 125, 125, val, angle);

			val += angle;
		}
	}

	public static void main(String[] args){ new Camenbert(); }
}
