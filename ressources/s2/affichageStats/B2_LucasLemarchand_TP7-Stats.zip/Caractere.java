import java.util.Arrays;

public class Caractere
{
	private int[] xi;
	private int[] ni;

	private Caractere(int[] xi, int[] ni)
	{
		this.xi = Arrays.copyOf(xi, xi.length);
		this.ni = Arrays.copyOf(ni, ni.length);
	}

	public static Caractere fabrique(int[] xi, int[] ni)
	{
		if (xi == null || ni == null) return null;		//il faut des valeurs

		if (xi.length != ni.length)   return null;		//ni doit etre egal à xi

		int pre, sui;
		for (int cpt = 1 ; cpt < xi.length ; cpt++)
		{
			pre = xi[cpt-1];
			sui = xi[cpt  ];

			if (pre >= sui)           return null;		//xi doit etre croissant
		}
		
		for (int val : ni)
			if (val <= 0)             return null;		//pour toute valeurs de ni > 0

		return new Caractere(xi, ni);
	}

	public int effectif(int valeur)
	{
		for (int cpt = 0 ; cpt < xi.length ; cpt++)
			if (this.xi[cpt] == valeur)
				return this.ni[cpt];

		return 0;
	}

	public int effectifTotal()
	{
		int total = 0;

		for (int val : this.ni)
			total += val;

		return total;
	}

	public double frequence(int valeur)
	{
		return (double) this.effectif(valeur) / this.effectifTotal();
	}

	public double frequenceCumulee(int valeur)
	{
		double total = 0.0;

		for (int cpt1 = 0 ; cpt1 < xi.length ; cpt1++)
			if (this.xi[cpt1] == valeur)
				for (int cpt2 = 0 ; cpt2 < (cpt1+1) ; cpt2++)
					total += this.frequence(this.xi[cpt2]);

		return total;
	}

	public int mode()
	{
		int iMax = 0;

		for (int cpt = 0 ; cpt < this.ni.length ; cpt++)
			if (this.ni[iMax] < this.ni[cpt]) iMax = cpt;

		return this.xi[iMax];
	}

	public double moyenne()
	{
		double somme = 0;

		for (int cpt = 0 ; cpt < this.xi.length ; cpt++)
			somme += this.xi[cpt] * this.ni[cpt];

		return somme / this.effectifTotal();
	}

	public double moment2()
	{
		int somme = 0;

		for (int cpt = 0 ; cpt < this.xi.length ; cpt++)
			somme += this.ni[cpt] * Math.pow(this.xi[cpt],2);

		return somme / this.effectifTotal();
	}

	public double variance()
	{
		double somme = 0;

		for (int cpt = 0 ; cpt < this.xi.length ; cpt++)
			somme += this.ni[cpt] * Math.pow(this.xi[cpt] - this.moyenne() ,2);

		return somme / this.effectifTotal();
	}

	public double ecartType()
	{
		return Math.sqrt(this.variance());
	}

	public double frequenceIntervalle(double t)
	{
		double min, max;
		int    arrondiMin = 0; 
		int    arrondiMax = 0;

		min = this.moyenne() - (t * ecartType());			// calcule des valeurs
		max = this.moyenne() + (t * ecartType());

		if (min <= this.xi[0])								// calcule des extrémités l'intervale [min ; max]
			arrondiMin = this.xi[0];
		else
			for (int cpt = 1 ; cpt < this.xi.length ; cpt++)
				if (this.xi[cpt] > min)
				{
					arrondiMin = this.xi[cpt - 1];
					break;
				}

		if (max >= this.xi[this.xi.length - 1])
			arrondiMax = this.xi[this.xi.length - 1];
		else
			for (int cpt = this.xi.length - 2 ; cpt >= 0 ; cpt--)
				if (this.xi[cpt] < max)
				{
					arrondiMax = this.xi[cpt + 1];
					break;
				}

		return this.frequenceCumulee(arrondiMax) - this.frequenceCumulee(arrondiMin)
		                                         + this.frequence       (arrondiMin);
	}

	public int getNbValeur()      { return this.xi.length; }
	public int getValeur  (int i) { return this.xi[i];     }
	public int getEffectif(int i) { return this.ni[i];     }

	public String toString()
	{
		String ligne = "+";
		for (int cpt = 0 ; cpt < this.xi.length+1 ; cpt++)
			ligne += "-----+";

		String sRet = ligne + "\n|xi   |" ;											//valeurs
		for (int cpt = 0 ; cpt < this.xi.length ; cpt++)
			sRet += String.format("%5d", this.xi[cpt]) + "|";

		sRet += "\n" + ligne + "\n|ni   |";											//effectifs
		for (int cpt = 0 ; cpt < this.ni.length ; cpt++)
			sRet += String.format("%5d", this.ni[cpt]) + "|";

		sRet += "\n" + ligne + "\n|fi   |";											//frequences
		for (int cpt = 0 ; cpt < this.ni.length ; cpt++)
			sRet += String.format("%5.2f", this.frequence(this.xi[cpt])) + "|";

		sRet += "\n" + ligne + "\n|pi   |";											//frequences cumulées
		for (int cpt = 0 ; cpt < this.ni.length ; cpt++)
			sRet += String.format("%5.2f", this.frequenceCumulee(this.xi[cpt])) + "|";

		sRet += "\n" + ligne                               + "\n" +
		        "effectif total : " + this.effectifTotal() + "\n" +
				"moyenne        : " + this.moyenne      () + "\n" +
				"écart type     : " + this.ecartType    () + "\n" +
				"mode           : " + this.mode         () + "\n" +
				"proportion entre m - 2o et m + 2o : " + (this.frequenceIntervalle(2.0)*100.0) + "%" ;

		return sRet;
	}
}
