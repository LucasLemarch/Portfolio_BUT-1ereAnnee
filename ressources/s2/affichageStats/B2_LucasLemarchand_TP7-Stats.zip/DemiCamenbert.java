import javax.swing.*;
import java.awt.Graphics;
import java.awt.Color;

public class DemiCamenbert extends JFrame
{
	private Metier metier;

	public DemiCamenbert()
	{
		this.metier = new Metier();

		int hauteurFenetre = 60 + metier.getNbValeur() * 20;	//on adapte la taille de la page au nombre de valeur à afficher
		if ( hauteurFenetre < 150 )								//on donne une taille minimum pour le demi-camenbert
			 hauteurFenetre = 150;

		this.setTitle("Demi-camenbert");
		this.setSize(300, hauteurFenetre);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void paint(Graphics g)
	{
		Color[] tabColor = new Color[] { Color.RED  , Color.BLUE, Color.PINK  , Color.CYAN,
		                                 Color.GREEN, Color.GRAY, Color.ORANGE, Color.YELLOW };

		super.paint(g);
		
		int angle;
		int val = 0;
		for (int i = 0 ; i < this.metier.getNbValeur() ; i++)
		{
			g.setColor(tabColor[i%8]);
			g.fillRect(200, 50 + (i*20), 10, 10);
			g.drawString("" + this.metier.getValeur(i),215,59 + (i*20));

			angle = (int) Math.round(this.metier.getFrequence(i) * 180.0);

			if (i == this.metier.getNbValeur() - 1)								//pour forcément arriver à 180°
				g.fillArc(25, 75, 150, 150, val, 180 - val);
			else
				g.fillArc(25, 75, 150, 150, val, angle);

			val += angle;
		}
	}

	public static void main(String[] args){ new DemiCamenbert(); }
}
