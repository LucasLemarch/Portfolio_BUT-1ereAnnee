import javax.swing.*;
import java.awt.Graphics;
import java.awt.Color;

public class DiagrammeABarres extends JFrame
{
	private Metier metier;

	private int hauteur;
	private int largeur;

	public DiagrammeABarres()
	{
		this.metier = new Metier();

		int max = 0;											//calcule de la hauteur de la fenetre
		for (int cpt = 0 ; cpt < this.metier.getNbValeur() ; cpt++)
			if ( max < this.metier.getEffectif(cpt) )
				 max = this.metier.getEffectif(cpt);

		this.hauteur = 75 + max;

		this.largeur = 100 + 50 * this.metier.getNbValeur();	//calcule de la largeur de la fenetre 

		this.setTitle("Diagramme à barres");
		this.setSize(this.largeur, this.hauteur);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void paint(Graphics g)
	{
		Color[] tabColor = new Color[] { Color.RED  , Color.BLUE, Color.PINK  , Color.CYAN,
		                                 Color.GREEN, Color.GRAY, Color.ORANGE, Color.YELLOW };

		super.paint(g);
		
		g.setColor(Color.BLACK);
		g.drawLine(50,0,50, this.hauteur - 25);												//délimitations
		g.drawLine(0,this.hauteur - 25,this.largeur, this.hauteur - 25);

		int val;
		for (int i = 0 ; i < this.metier.getNbValeur() ; i++)
		{
			val = this.metier.getEffectif(i);

			g.setColor(Color.BLACK);
			g.drawLine(45,this.hauteur - 25 - val,55, this.hauteur - 25 - val);				//graduation
			g.drawString( String.format("%6d",this.metier.getEffectif(i)),15, this.hauteur - 22 - val);

			g.drawLine(94 + (i*50), this.hauteur - 21,94 + (i*50), this.hauteur - 25);		//valeur
			g.drawString( "" + this.metier.getValeur(i), 91 + (i*50), this.hauteur - 10);
			
			g.setColor(tabColor[i%8]);	
			g.fillRect(90 + (i*50), this.hauteur - 25 - val, 10, val);						//barres
		}
	}

	public static void main(String[] args){ new DiagrammeABarres(); }
}
