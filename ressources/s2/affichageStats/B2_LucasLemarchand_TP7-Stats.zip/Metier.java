public class Metier
{
	private Caractere c;

	public Metier()
	{
		this.c = Caractere.fabrique(new int[]{  0,  1,  2, 3, 4, 5, 6},
		                            new int[]{151,157,122,93,42,23,12} );
	}

	public int    getValeur       (int i) { return this.c.getValeur    (i); }
	public int    getNbValeur     ()      { return this.c.getNbValeur  ( ); }
	public int    getEffectif     (int i) { return this.c.getEffectif  (i); }
	public int    getEffectifTotal()      { return this.c.effectifTotal( ); }
	public double getFrequence    (int i) { return this.c.frequence(this.getValeur(i)); }
}
