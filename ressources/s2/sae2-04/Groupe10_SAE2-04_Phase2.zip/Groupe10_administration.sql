-- CAS BD'Lire
-- Programmeurs : Harel      Corentin B1, 
--                Decharrois Adrien   B1, 
--                Lemarchand Lucas    B2
-- Date : 08/06/22



-- REQUETE A 

-- L’administrateur a les droits de création/suppression des bases, des tables, et toutes les opérations de lecture/écriture sur la base et l’affectation des privilèges aux autres 
-- utilisateurs/roles

GRANT CREATE, DELETE, SELECT, UPDATE
ON TABLE Client, Editeur, Auteur, Serie, BD, Vente, Concerner
TO administrateur WITH GRANT OPTION; 

GRANT CREATE, DELETE, SELECT, UPDATE
ON DATABASE
TO administrateur WITH GRANT OPTION;

-- REQUETE B

-- b) Le vendeur a les droits en lecture/écriture sur la table des ventes et des clients et sur la table Concerner entre les deux.

GRANT SELECT, UPDATE
ON TABLE Vente, Client, Concerner
TO vendeur;

-- REQUETE C

-- c) l’éditeur a les droits du vendeur plus les lectures/écritures sur les tables BD, Serie, et Auteur.

GRANT SELECT, UPDATE
ON TABLE BD, Serie, Auteur, Vente, Client, Concerner
TO editeur;