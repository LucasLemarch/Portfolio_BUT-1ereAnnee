-- CAS BD'Lire
-- Programmeurs : Harel      Corentin B1, 
--                Decharrois Adrien   B1, 
--                Lemarchand Lucas    B2
-- Date : 08/06/22


-- FONCTION A

-- Ecrire une fonction qui prend en paramètre un numéro d’auteur dessinateur et qui renvoie pour 
-- chaque titre de BD de l’auteur, le nombre d’exemplaires vendus de cette BD.

DROP TYPE typePROC_A CASCADE;
CREATE TYPE typePROC_A AS (titre TEXT, nbExemplairesVendus BIGINT);

CREATE OR REPLACE FUNCTION proc_a(un_numAD BD.numAuteurDessinateur%TYPE)
RETURNS SETOF typePROC_A AS $$
	BEGIN
		RETURN QUERY SELECT titre, SUM(quantite) FROM BD b JOIN Concerner c ON b.isbn = c.isbn 
		             WHERE numAuteurDessinateur = un_numAD GROUP BY titre;
	END
$$ LANGUAGE PlpgSQL;

/* Résultat :

SELECT * FROM proc_a(30);

         titre         | nbexemplairesvendus 
-----------------------+---------------------
 Pauvres mais fiers    |                 678
 Les rois du rire      |                 976
 Au bonheur des drames |                 457
 Jours de stars        |                 135
 Stars toujours !      |                 567
 Stars d un jour…      |                 572
(6 lignes)


SELECT * FROM proc_a(63);

 titre | nbexemplairesvendus 
-------+---------------------
(0 ligne)
*/



-- FONCTION B

-- Écrire une fonction qui prend en paramètre le nom d’une série de BD et qui renvoie pour chaque 
-- titre de la série le nombre d’exemplaires vendus et le chiffre d’affaire réalisé par titre.

DROP TYPE typePROC_B CASCADE;
CREATE TYPE typePROC_B AS (titre TEXT, nbExemplairesVendus BIGINT, chiffresAffaires FLOAT);

CREATE OR REPLACE FUNCTION proc_b(un_nomSerie Serie.nomSerie%TYPE)
RETURNS SETOF typePROC_B AS $$ 
	BEGIN
		RETURN QUERY SELECT titre, SUM(quantite), SUM(prixVente * quantite) 
		             FROM   Serie s JOIN BD b        ON s.numserie = b.numserie 
		                            JOIN Concerner c ON b.isbn = c.isbn 
		             WHERE  nomSerie = un_nomSerie 
		             GROUP BY titre, nomserie; 
	END
$$ LANGUAGE PlpgSQL;

/* Résultat :

SELECT * FROM proc_b('Peter Pan');

    titre     | nbexemplairesvendus | chiffresaffaires 
--------------+---------------------+------------------
 Crochet      |                 780 |            10920
 Destins      |                 406 |             5684
 Londres      |                 245 |             3430
 Mains rouges |                 456 |             6384
 Opikanoba    |                1345 |            18830
 Tempête      |                 745 |            10430
(6 lignes)


SELECT * FROM proc_b('abcdefghi');

 titre | nbexemplairesvendus | chiffresaffaires 
-------+---------------------+------------------
(0 ligne)
*/



-- FONCTION C

-- Écrire une fonction qui prend en paramètre un nom d’éditeur et un nom d’auteur dessinateur et un 
-- nom d’auteur scénariste, et qui renvoie la liste des BD de ces auteurs éditées par l’éditeur 
-- choisi. 
-- Si l’éditeur n’a pas édité de BD de ces auteurs, ou qu’il n’existe pas de BD de ces deux auteurs, 
-- on devra générer le message suivant « l’éditeur % n’a pas édité de BD des auteurs % et %» où on 
-- remplacera les « % » par les noms correspondants.

CREATE OR REPLACE FUNCTION proc_c(un_nomE Editeur.nomEditeur%TYPE, un_nomAD Auteur.nomAuteur%TYPE, un_nomAS Auteur.nomAuteur%TYPE)
RETURNS SETOF BD.titre%TYPE AS $$
	BEGIN
		RETURN QUERY SELECT titre FROM BD b JOIN Auteur  a1 ON b.numAuteurDessinateur = a1.numAuteur
		                                                JOIN Auteur  a2 ON b.numAuteurScenariste  = a2.numAuteur
		                                                JOIN Serie   s  ON b.numSerie             = s.numSerie
		                                                JOIN Editeur e  ON s.numEditeur           = e.numEditeur
		             WHERE  a1.nomAuteur = un_nomAD AND 
		                    a2.nomAuteur = un_nomAS AND 
		                    e.numEditeur = (SELECT numEditeur FROM Editeur e WHERE e.nomEditeur = un_nomE)
		             GROUP BY titre, nomEditeur; 
		IF (NOT FOUND) THEN
			Raise exception 'l éditeur % n’a pas édité de BD des auteurs % et %',un_nomE,un_nomAD,un_nomAS;
		END IF;
	END
$$ LANGUAGE PlpgSQL;

/* Résultat :

SELECT * FROM proc_c('Vents d Ouest','Loisel','Loisel');

    proc_c    
--------------
 Crochet
 Destins
 Londres
 Mains rouges
 Opikanoba
 Tempête
(6 lignes)


SELECT * FROM proc_c('Tonkan','Aubin','Watanabe');

ERREUR:  l éditeur Tonkan n’a pas édité de BD des auteurs Aubin et Watanabe
*/



-- FONCTION D

-- Créer une fonction stockée qui prend en paramètre le nom d’une série de BD et qui renvoie les 
-- clients ayants acheté tous les albums de la série (utiliser des boucles FOR et/ou des curseurs).
-- Si aucun client ne répond à la requête alors on affichera un message d’avertissement ‘Aucun 
-- client n’a acheté tous les exemplaires de la série %’, en complétant le ‘ %’ par le nom de la 
-- série.

CREATE OR REPLACE FUNCTION proc_d(un_nomSerie Serie.nomSerie%TYPE)
RETURNS SETOF Client AS $$
	DECLARE
		un_client  Client%ROWTYPE;
		nbBDSerie  INT;
		nbBDAchete INT;
		nbResultat INT;
	BEGIN
		--On compte le nombre de bd qu'il y a dans la série donnée
		SELECT COUNT(isbn) INTO nbBDSerie FROM BD b JOIN Serie s ON b.numSerie = s.numSerie WHERE nomSerie = un_nomSerie;	
		
		--On créer une variable contenant le nombre de client ayant acheté toutes les bd d'une série 
		nbResultat = 0;

		--On fait une boucle explorant tout les clients
		FOR un_client IN SELECT * FROM Client
		LOOP
			--On compte le nombre de bd différente de la serie que le client a acheté
			SELECT	COUNT(DISTINCT(isbn)) INTO nbBDAchete
			FROM	Vente v JOIN Concerner c ON v.numVente = c.numVente 
			WHERE	un_client.numClient = numClient 												AND
					isbn IN (	SELECT	isbn FROM	BD b JOIN Serie s ON b.numSerie = s.numSerie
								WHERE	nomSerie = un_nomSerie											);

			--Si le client à acheté autant de bd différentes que de bd qu'il y a dans la série c'est qu'il les a toutes achetées
			IF (nbBDSerie = nbBDAchete) THEN
				RETURN NEXT un_client;
				nbResultat = nbResultat + 1;
			END IF;
		END LOOP;

		--Si aucun client n'a acheté tous les exemplaires de la série nous renvoyons une erreur
		IF (nbResultat = 0) THEN
			Raise exception 'Aucun client n’a acheté tous les exemplaires de la série %', un_nomSerie;
		END IF;
	END
$$LANGUAGE PLpgSQL;

/* Résultat :

SELECT * FROM proc_d('Peter Pan');

 numclient | nomclient |  numtelclient  |   mailclient    
-----------+-----------+----------------+-----------------
         6 | Timable   | 06 56 53 01 40 | mail@limelo.com
(1 ligne)


SELECT * FROM proc_d('Asterix le gaulois');

ERREUR:  Aucun client n’a acheté tous les exemplaires de la série Asterix le gaulois
*/



-- REQUETE E

-- Créer une fonction qui prend en paramètre un nombre nbBD de BD et une année donnée, et qui 
-- renvoie la liste des éditeurs ayant vendu au moins ce nombre de BD dans l’année en question. 
-- Si aucun éditeur ne répond à la requête, le signaler par un message approprié. 

--Nous allons ici utilisé une vue créé lors de la phase 1. Celle-ci était la requete I et voici son code :
DROP VIEW IF EXISTS bdEditeur;
CREATE VIEW bdEditeur
AS	SELECT	EXTRACT( YEAR FROM dteVente) as annee, nomEditeur, SUM(quantite) as quantite_achete
	FROM	Vente v JOIN Concerner c ON v.numVente   = c.numVente 
					JOIN BD b        ON b.isbn       = c.isbn
					JOIN Serie s     ON s.numSerie   = b.numSerie
					JOIN Editeur e   ON e.numEditeur = s.numEditeur
	GROUP BY annee, nomEditeur
	ORDER BY annee, nomEditeur;

CREATE OR REPLACE FUNCTION proc_e(nbBD INT, une_annee INT)
RETURNS SETOF Editeur AS $$
	BEGIN
		RETURN QUERY SELECT e.* FROM bdEditeur b JOIN Editeur e ON b.nomEditeur = e.nomEditeur 
		             WHERE annee = une_annee AND quantite_achete >= nbBD;
		IF (NOT FOUND) THEN
			Raise exception 'Aucun editeur a vendu minimum % bd en %',nbBD,une_annee;
		END IF;
	END
$$LANGUAGE PLpgSQL;

/* Résultat :

SELECT * FROM proc_e(700,2012);

 numediteur | nomediteur |                adresseediteur                | numtelediteur  |           mailediteur            
------------+------------+----------------------------------------------+----------------+----------------------------------
          1 | Delcourt   | 8     rue Leon Jouhaux,         75010  Paris | 01 56 03 92 20 | accueil-paris@groupedelcourt.com
          8 | Lombard    | 57    rue Gaston TessierF 7     5019 Paris   |                | info@Lombard.be
(2 lignes)


SELECT * FROM proc_e(123,4567);

ERREUR:  Aucun editeur a vendu minimum 123 bd en 4567
*/



-- FONCTION F

-- Écrire une fonction qui prend en paramètre une année donnée, et un nom d’éditeur et qui renvoie 
-- le(s) tuple(s) comportant l’année et le nom de l’éditeur d’une part, associé au nom et email 
-- du(des) client(s) d’autre part ayant acheté le plus de BD cette année-là chez cet éditeur. 

DROP TYPE typePROC_F CASCADE;
CREATE TYPE typePROC_F AS (annee FLOAT, nomEditeur VARCHAR(23), nomClient VARCHAR(11), mailClient TEXT);

CREATE OR REPLACE FUNCTION proc_f(annee FLOAT, un_nomE Editeur.nomEditeur%TYPE)
RETURNS SETOF typePROC_F AS $$ 
	BEGIN
		--on créer une vue des editeurs avec leurs client et leurs nombres d'achats par année
		DROP VIEW IF EXISTS vuePROC_F CASCADE;
		CREATE VIEW vuePROC_F AS
			SELECT nomEditeur, EXTRACT(YEAR from dteVente) AS year, nomClient, mailClient, SUM(quantite) AS quantiteAchat 
			FROM Editeur e JOIN Serie s      ON s.numEditeur = e.numEditeur 
			               JOIN BD b         ON b.numSerie   = s.numSerie 
			               JOIN Concerner c1 ON c1.isbn      = b.isbn 
			               JOIN Vente v      ON v.numVente   = c1.numVente 
			               JOIN Client c     ON c.numClient  = v.numClient 
			GROUP BY c.numClient, nomEditeur, year
			ORDER BY EXTRACT(YEAR FROM dteVente);

		--on renvoie le client avec la plus grand quantité acheté pour l'éditeur et l'année renseigné
		RETURN QUERY SELECT year, nomEditeur, nomClient, mailClient FROM vuePROC_F
		             WHERE  year = annee AND nomEditeur = un_nomE AND quantiteAchat = (SELECT MAX(quantiteAchat)
		                                                                               FROM   vuePROC_F
		                                                                               WHERE  year = annee and nomEditeur = un_nomE);
	END
$$ LANGUAGE PlpgSQL;

/* Résultat :

SELECT * FROM proc_f(2011, 'Dargaud');

 annee | nomediteur | nomclient |  mailclient   
-------+------------+-----------+---------------
  2011 | Dargaud    | Hauraque  | mail@odie.net
(1 ligne)
*/



-- FONCTION G

-- Écrire une fonction SQL utilisant un curseur, qui classe pour un éditeur dont le nom est donné 
-- en entrée, les clients de cet éditeur en trois catégories selon le nombre de BD qu’ils leur ont 
-- achetées (attention on ne comptabilisera pas les quantités achetées, seulement le nombre de BD 
-- distinctes) : les « très bons clients » (plus de 10 achats strictement), les « bons clients » 
-- (entre 2 et 10 BD), les « mauvais clients » (moins ou égal à 2 BD) 

DROP TYPE PROC_G CASCADE;
CREATE TYPE PROC_G AS (nomClient VARCHAR(11),categorie TEXT);

CREATE OR REPLACE FUNCTION proc_g(un_nomEditeur Editeur.nomEditeur%TYPE)
RETURNS SETOF PROC_G AS $$
	DECLARE
		--création d'un curseur parcourant les clients de l'editeur choisi
		curs CURSOR FOR SELECT DISTINCT(cl.numClient) 
		                FROM Client cl JOIN Vente v      ON cl.numClient = v.numClient 
		                               JOIN Concerner co ON v.numVente   = co.numVente 
		                               JOIN BD b         ON co.isbn      = b.isbn 
		                               JOIN Serie s      ON b.numSerie   = s.numSerie
		                               JOIN Editeur e    ON s.numEditeur = e.numEditeur 
		                WHERE nomEditeur = un_nomEditeur;
		un_numClient Client.numClient%TYPE;
		une_categ    PROC_G;
		nbBD         INT;
	BEGIN
		OPEN curs;
		LOOP
			FETCH curs INTO un_numClient;
			EXIT WHEN NOT FOUND;

			--on récupère le nom du client
			SELECT nomClient INTO une_categ.nomClient
			FROM Client WHERE numClient = un_numClient;

			--on compte le nombre de bd acheté du client chez l'éditeur choisi
			SELECT COUNT(numVente) FROM Vente INTO nbBD
			WHERE  numClient = un_numClient AND 
			       numVente IN (SELECT numVente FROM Concerner c JOIN BD b      ON c.isbn       = b.isbn
			                                                     JOIN Serie s   ON b.numSerie   = s.numSerie
			                                                     JOIN Editeur e ON s.numEditeur = e.numEditeur
			                    WHERE nomEditeur = un_nomEditeur                                              );
			
			--on attribut la categorie du client en fonction du nombre de bd acheté
			IF (nbBD <= 2) THEN 
				une_categ.categorie = 'mauvais client';
			ELSE 
				IF (nbBD <= 10) THEN 
					une_categ.categorie = 'bon client';
				ELSE
					une_categ.categorie = 'très bon client';
				END IF;
			END IF;

			RETURN NEXT une_categ;
		END LOOP;
		CLOSE curs;
		RETURN;
	END
$$LANGUAGE PLpgSQL;

/* Résultat :

SELECT * FROM proc_g('Dargaud');

  nomclient  |    categorie    
-------------+-----------------
 Torguesse   | bon client
 Fissile     | bon client
 Hauraque    | très bon client
 Poret       | bon client
 Menvussa    | mauvais client
 Timable     | bon client
 Don Devello | bon client
 Ohm         | mauvais client
 Ginal       | mauvais client
 Hautine     | mauvais client
 Kament      | mauvais client
(11 lignes)
*/



-- FONCTION H

-- Ecrire une fonction qui renvoie pour tous les clients sa plus petite quantité achetée (min) et 
-- sa plus grande quantité achetée (max) et la somme totale de ses quantités achetées de BD.
-- Vous devrez donc créer un type composite ‘clientBD’ comportant quatre attributs: l'identifiant 
-- du client, son nom, sa plus petite quantité achetée, sa plus grande quantité achetée, et la 
-- somme totale de ses quantités achetées.  Votre procédure devra retourner des éléments de ce 
-- type de données.
-- On rajoutera le comportement suivant : si le minimum est égal au maximum pour un client, on 
-- affichera le message 'Egalité du minimum et maximum pour le client %' en précisant le nom du client.
-- NB : utiliser une boucle FOR ou un curseur...

DROP TYPE clientBD CASCADE;
CREATE TYPE clientBD AS (numClient INT, nomClient VARCHAR(11), qAchatMin INT,qAchatMax INT, totQAchat INT);

CREATE OR REPLACE FUNCTION proc_h()
RETURNS SETOF clientBD AS $$
	DECLARE
		un_numClient Client.numClient%TYPE;
		une_categ    clientBD;
	BEGIN
		FOR un_numClient IN SELECT numClient FROM Client
		LOOP
			SELECT cl.numClient, nomClient, MIN(quantite) AS qAchatMin, MAX(quantite) AS qAchatMax, SUM(quantite) AS totQAchat
			INTO une_categ FROM Client cl JOIN Vente v      ON cl.numClient = v.numClient 
			                              JOIN Concerner co ON co.numVente  = v.numVente 
			WHERE cl.numClient = un_numClient
			GROUP BY cl.numClient;

			IF (une_categ.qAchatMin = une_categ.qAchatMax) THEN
				RAISE NOTICE 'Egalité du minimum et maximum pour le client %', une_categ.nomClient;
			END IF;

			RETURN NEXT une_categ;
		END LOOP;
	END
$$LANGUAGE PLpgSQL;


/* Résultat :

SELECT * FROM proc_h();

 numclient |  nomclient  | qachatmin | qachatmax | totqachat 
-----------+-------------+-----------+-----------+-----------
         1 | Torguesse   |       225 |       938 |      2645
         2 | Fissile     |        35 |       924 |      3651
         3 | Hauraque    |        32 |       742 |      4307
         4 | Poret       |        72 |       784 |      8816
         5 | Menvussa    |       135 |       976 |      4093
         6 | Timable     |        34 |      1345 |      6639
         7 | Don Devello |       253 |       796 |      5664
         8 | Ohm         |       274 |      1346 |      6159
         9 | Ginal       |       447 |       857 |      4564
        10 | Hautine     |       137 |       976 |      3865
        11 | Kament      |       346 |       576 |      1691
(11 lignes)
*/



-- FONCTION I

-- Ecrire une fonction qui supprime une vente dont l'identifiant est passé en paramètre.
-- Vérifier d'abord que la vente associée à l'identifiant existe, si elle n'existe pas afficher un 
-- message d'erreur le mentionnant; si elle existe on la supprime. Cette suppression va générer une 
-- violation de clé étrangère dans la table 'Concerner'. Pour gérer cela, on utilisera le code 
-- d'erreur FOREIGN_KEY_VIOLATION dans un bloc EXCEPTION dans lequel on supprimera tous les tuples 
-- de la table 'Concerner' qui possèdent ce numéro de vente, avant de supprimer la vente elle même. 
-- On pourra au passage afficher aussi un message d'avertissement sur cette exception.

CREATE OR REPLACE FUNCTION proc_i(numero_de_vente Vente.numVente%TYPE)
RETURNS void AS $$ 
	BEGIN
		PERFORM * FROM Vente WHERE numVente = numero_de_vente;
		IF (NOT FOUND)
		THEN
			RAISE EXCEPTION 'Le numéro de vente % saisie n existe pas', numero_de_vente;
		ELSE
			DELETE FROM Concerner c WHERE numVente = numero_de_vente;
			DELETE FROM Vente v     WHERE numVente = numero_de_vente; 
		END IF;
	END
$$ LANGUAGE PlpgSQL;

/* Résultat :

SELECT * FROM proc_i(1);

 proc_i 
--------
 
(1 ligne)


SELECT * FROM proc_i(1);

ERREUR:  Le numéro de vente 1 saisie n existe pas
*/



-- FONCTION J

-- On souhaite classer tous les clients par leur quantité totale d'achats de BD. Ainsi on veut 
-- associer à chaque client son rang de classement en tant qu'acheteur dans l'ordre décroissant des 
-- quantités achetées. Ainsi le client de rang 1 (classé premier) aura totalisé le plus grand nombre 
-- d'achats.
-- Vous devez donc créer un nouveau type de données ‘rangClient’, qui associe l'identifiant du 
-- client, son nom et son classement dans les acheteurs (attribut nommé ‘rang’).
-- Ecrire une fonction qui renvoie pour tous les clients, son identifiant, son nom et son 
-- classement d'acheteur décrit ci-dessus.
-- NB : on pourra avantageusement utiliser une boucle FOR ou un curseur... 

DROP TYPE rangClient CASCADE;
CREATE TYPE rangClient AS (numClient int, nomClient varchar(11), rang INT);

CREATE OR REPLACE FUNCTION proc_j()
RETURNS SETOF rangClient AS $$ 
	DECLARE
		un_numClient Client.numClient%TYPE;
		une_categ    rangClient;
		cpt          INT;
	BEGIN
		cpt = 1;

		--on fait une boucle parcourant les client du plus grand acheteur au plus petit
		FOR un_numClient IN SELECT   cl.numClient FROM Client cl JOIN Vente v      ON cl.numClient = v.numClient 
		                                                         JOIN Concerner co ON co.numVente  = v.numVente 
		                    GROUP BY cl.numClient
		                    ORDER BY SUM(quantite) DESC
		LOOP
			SELECT cl.numClient, nomClient INTO une_categ.numClient, une_categ.nomClient
			FROM Client cl JOIN Vente v      ON cl.numClient = v.numClient 
			               JOIN Concerner co ON co.numVente  = v.numVente 
			WHERE cl.numClient = un_numClient
			GROUP BY cl.numClient;

			--on attribut le rang
			une_categ.rang = cpt;
			cpt = cpt + 1;

			RETURN NEXT une_categ;
		END LOOP;
	END
$$ LANGUAGE PlpgSQL;

/* Résultat :

SELECT * FROM proc_j();

 numclient |  nomclient  | rang 
-----------+-------------+------
         4 | Poret       |    1
         6 | Timable     |    2
         8 | Ohm         |    3
         7 | Don Devello |    4
         9 | Ginal       |    5
         3 | Hauraque    |    6
         5 | Menvussa    |    7
         2 | Fissile     |    8
        10 | Hautine     |    9
         1 | Torguesse   |   10
        11 | Kament      |   11
(11 lignes)
*/